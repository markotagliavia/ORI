/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudije;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author kokoliko
 */
public class Sudije {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /* Map<String, int[]> lista;
        lista = new HashMap<String, int[]>();
        Scanner fileIn = null;
		try {
			fileIn = new Scanner(new File("M2.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn.hasNext())
		{
			String line = fileIn.nextLine();
			String pom[] = line.split(",");
                        String sudija = pom[10];
                        int gh = Integer.parseInt(pom[4]);
                        int ga = Integer.parseInt(pom[5]);
                        
                            if(lista.containsKey(sudija))
                            {
                                if(gh - ga > 0) lista.get(sudija)[0]++;
                                else if (gh == ga) lista.get(sudija)[1]++;
                                else lista.get(sudija)[2]++;
                            }
                            else
                            {
                                int[] niz = new int[3];
                                niz[0] = 0; niz[1] = 0; niz[2] = 0;
                                lista.put(sudija, niz);
                            }

                }
                
                
     		try {
			PrintWriter out = new PrintWriter("izlazSudije.txt");
			String text = "";
				for(Map.Entry<String, int[]> entry : lista.entrySet())
				{
                                    text = entry.getKey() + "," + entry.getValue()[0]+","+entry.getValue()[1]+","+entry.getValue()[2];
                                    out.println(text);
                                }		
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
       HashMap<String, double[]> mapaJacina = new HashMap<String, double[]>();
             Scanner fileIn2 = null;
		try {
			fileIn2 = new Scanner(new File("timoviRating.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn2.hasNext())
		{
			String line = fileIn2.nextLine();
			String pom[] = line.split(":");
                        String pom2[] = pom[1].split(",");
                        double golman = Double.parseDouble(pom2[0]);
                        double odbrana = Double.parseDouble(pom2[1]);
                        double sredina = Double.parseDouble(pom2[2]);
                        double napad = Double.parseDouble(pom2[3]);
                         //B = (A - min⁡(A)) / (max⁡(A) - min⁡(A)) * ( D - C ) + C
                         golman = (golman/100.0) * 1000.0;
                         odbrana = (odbrana/400.0) * 1000.0;
                         sredina = (sredina/400.0) * 1000.0;
                         napad = (napad/200.0) * 1000.0;
                        double[] niz = new double[4];
                        niz[0] = golman; niz[1] = odbrana; niz[2] = sredina; niz[3] = napad;
                        mapaJacina.put(pom[0], niz);
                }
                fileIn2.close();
       
       
       
       
       ArrayList<double[]> al = new ArrayList<double[]>(); 
       Scanner fileIn3 = null;
		try {
			fileIn3 = new Scanner(new File("M2.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn3.hasNext())
		{
			String line = fileIn3.nextLine();
			String pom[] = line.split(",");
                        String domaci = pom[2];
                        String gosti = pom[3];
                        int gh = Integer.parseInt(pom[4]);
                        int ga = Integer.parseInt(pom[5]);
                        
                        if(mapaJacina.containsKey(domaci) && mapaJacina.containsKey(gosti))
                        {
                            double[] niz = new double[11];
                            niz[0] = mapaJacina.get(domaci)[0]*1.0;
                            niz[1] = mapaJacina.get(domaci)[1]*1.0;
                            niz[2] = mapaJacina.get(domaci)[2]*1.0;
                            niz[3] = mapaJacina.get(domaci)[3]*1.0;
                            niz[4] = mapaJacina.get(gosti)[0]*1.0;
                            niz[5] = mapaJacina.get(gosti)[1]*1.0;
                            niz[6] = mapaJacina.get(gosti)[2]*1.0;
                            niz[7] = mapaJacina.get(gosti)[3]*1.0;
                            if(gh == ga)
                            {
                                niz[8] = 0.0;
                                niz[9] = 1.0;
                                niz[10] = 0.0;
                            }
                            else if(gh > ga)
                            {
                                niz[8] = 1.0;
                                niz[9] = 0.0;
                                niz[10] = 0.0;
                            }
                            else
                            {
                                niz[8] = 0.0;
                                niz[9] = 0.0;
                                niz[10] = 1.0;                            
                            }
                            
                            al.add(niz);
                        }
                }
                fileIn3.close();
                
                
                
                
                try {
			PrintWriter out = new PrintWriter("izlazNeuronskaTrening.txt");
			String text = "";
				for(short i = 0; i < al.size(); i++)
				{
                                    double[] n = al.get(i);
                                    text = n[0]+ "," + n[1]+","+n[2]+","+n[3]+ "," + n[4]+","+n[5]+","+n[6]+ "," + n[7]+","+n[8]+","+n[9]+","+n[10];
                                    out.println(text);
                                }		
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                
                
    }
    
}
