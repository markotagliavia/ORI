package temp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Double, int[]> mapa = new HashMap<Double, int[]>();
		ArrayList<Double> lista = new ArrayList<Double>();
		Scanner fileIn = null;
		try {
			fileIn = new Scanner(new File("a.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn.hasNext())
		{
			String line = fileIn.nextLine();
			String pom[] = line.split(",");
			String s1 = pom[0].replaceAll("\"", "");
			String s2 = pom[1].replaceAll("\"", "");
			double mr = Math.round(Double.parseDouble(s1)*10);
			mr = mr/10;
			int ishod = Integer.parseInt(s2);
			if(mapa.containsKey(mr))
			{
				if(ishod == -1) mapa.get(mr)[2]++;
				else if(ishod == 0) mapa.get(mr)[1]++;
				else mapa.get(mr)[0]++;
			}
			else
			{
				int niz[] = new int[3];
				niz[0] = 0; niz[1] = 0; niz[2] = 0;
				if(ishod == -1) niz[2] = 1;
				else if(ishod == 0) niz[1] = 1;
				else niz[0] = 1;
				mapa.put(mr, niz);
				lista.add(mr);
			}
		}
		
		lista.sort(null);
		
		for(short i = 0; i < lista.size(); i++)
		{
			for(Map.Entry<Double, int[]> entry : mapa.entrySet())
			{
				if(entry.getKey().equals(lista.get(i))) 
					System.out.println(entry.getKey() + "\t" + entry.getValue()[0] + " "+ entry.getValue()[1] + " "+entry.getValue()[2]);
			}
		}
		
		try {
			PrintWriter out = new PrintWriter("izlaz.txt");
			String text = "";
			for(short i = 0; i < lista.size(); i++)
			{
				for(Map.Entry<Double, int[]> entry : mapa.entrySet())
				{
					if(entry.getKey().equals(lista.get(i))) 
					{
						text = entry.getKey() + "," + entry.getValue()[0] + ","+ entry.getValue()[1] + ","+entry.getValue()[2];
						out.println(text);
					}
				}
			}
			
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
