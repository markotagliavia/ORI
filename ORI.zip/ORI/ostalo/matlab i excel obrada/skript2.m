fid2 = fopen('zaObradu.csv');
M2 = textscan(fid,'%*s %*s %*s %*s %d %d %*s %d %d %*s %*s %d %d %d %d %d %d %d %d %d %d %d %d %f %f %f %*[^\n]','Delimiter',',');
fclose(fid2);