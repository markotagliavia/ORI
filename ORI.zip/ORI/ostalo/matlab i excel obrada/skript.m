fid = fopen('zaObradu.csv');
M = textscan(fid,'%*s %*s %*s %*s %d %d %*s %d %d %*s %*s %*[^\n]','Delimiter',',');
fclose(fid);