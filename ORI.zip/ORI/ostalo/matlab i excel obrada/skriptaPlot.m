data = csvread('izlaz.csv');
mr = data(:,1);
pobedeDomacin = data(:,2);
nereseno = data(:,3);
pobedeGost = data(:,4);
figure
plot(mr, pobedeDomacin, '--o', mr, nereseno, 'r--x', mr, pobedeGost, 'c--*');
