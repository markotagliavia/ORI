
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kokoliko
 */
public class FileManip {
    
    BufferedWriter out = null;
    BufferedReader in = null;
     
    public void clear(String file)
    {
                /*FileWriter fwOb = null; 
        try {
            fwOb = new FileWriter(file, false);
        } catch (IOException ex) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, ex);
        }
        PrintWriter pwOb = new PrintWriter(fwOb, false);
        pwOb.flush();
        pwOb.close();
        try {
            fwOb.close();
        } catch (IOException ex) {
            Logger.getLogger(File.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        try {
			out = new BufferedWriter(new FileWriter(file));
			out.flush();
                        out.write("");
		} catch (Exception e){
			e.printStackTrace();
        } finally {
            if(out != null)
                try {
                    out.close();
                } catch (Exception e) {
        			e.printStackTrace();
                }
    }
   }
    
     public void saveText(String file, List<String> text) {
		
		try {
			out = new BufferedWriter(new FileWriter(file));
			out.flush();
			for(int i=0; i<text.size(); i++) {
				out.write(text.get(i));
				
				if(i!=text.size()-1)
					out.newLine();
			}
                      JOptionPane.showMessageDialog(null, "Database succesfully updated!", "Succes", JOptionPane.INFORMATION_MESSAGE);
		} catch (Exception e){
			e.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Database NOT succesfully updated!", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            if(out != null)
                try {
                    out.close();
                } catch (Exception e) {
        			e.printStackTrace();
                }
        }
    }
     
     
     
     public String[] loadText(String file) {
		
		String[] pom = new String[10000];
		String line;
		int pomSize = 0;
		try {
                    String path = System.getProperty("user.dir");
			in = new BufferedReader(new FileReader(path+"\\"+file));
			while ((line = in.readLine()) != null) {
					pom[pomSize]=line;
					pomSize++;
			}
		} catch (Exception e) {
			e.printStackTrace();
        } finally {
            if(in != null)
                try {
                    in.close();
                } catch (Exception e) {
        			e.printStackTrace();
                }
        }
		
		String[] ret = new String[pomSize];
		
		for(int i=0; i<pomSize; i++)
		{
			ret[i]=pom[i];
		}
		
		return ret;
	}
  }

