/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neural;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tijana-PC
 */

    public class SumNode
    {
        private ArrayList<Double> x;

        public SumNode()
        {
            x = new ArrayList<Double>();
        }
        /// <summary>
        /// Suma svih elemenata
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public double forward(ArrayList<Double> x)
        {
            this.x = x;
            double sum = 0;
            for(int i = 0; i < x.size(); i++) sum+=x.get(i);
            return sum;
        }
        /// <summary>
        /// Izvod funkcije po svakom elementu
        /// z = x + y 
        /// dz/dx = 1 => dx = dz
        /// dz/dy = 1 => dy = dz
        /// </summary>
        /// <param name="dz"></param>
        /// <returns></returns>
        public ArrayList<Double> backward(double dz)
        {
            ArrayList<Double> ret = new ArrayList<Double>();
            for(int i = 0; i < x.size(); i++)  ret.add(dz);
            return ret;
        }
    }
