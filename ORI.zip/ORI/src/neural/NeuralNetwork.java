/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neural;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tijana-PC
 */

   public class NeuralNetwork
    {
        public ArrayList<NeuralLayer> layers; 

    public ArrayList<NeuralLayer> getLayers() {
        return layers;
    }

    public void setLayers(ArrayList<NeuralLayer> layers) {
        this.layers = layers;
    }
        

        public NeuralNetwork()
        {
            this.layers = new ArrayList<NeuralLayer>();
        }

        public void Add(NeuralLayer layer)
        {
            this.layers.add(layer);
        }

        public ArrayList<Double> forward(ArrayList<Double> x)
        {
            ArrayList<Double> prev_layer_output = new ArrayList<Double>();

            for (int i = 0; i < this.layers.size(); i++)
            {
                if (i == 0)
                    prev_layer_output = layers.get(i).forward(x);
                else
                    prev_layer_output = layers.get(i).forward(prev_layer_output);
            }

            return prev_layer_output;
        }

        public ArrayList<ArrayList<Double>> backward(ArrayList<ArrayList<Double>> dz)
        {
            ArrayList<ArrayList<Double>> next_layer_dz = new ArrayList<ArrayList<Double>>();
            for (int i = layers.size() - 1; i >= 0; i--)
            {
                if (i == (layers.size() - 1))
                    next_layer_dz = layers.get(i).backward(dz);
                else
                    next_layer_dz = layers.get(i).backward(next_layer_dz);
            }

            return next_layer_dz;

        }

        public void updateWeights(double learningRate, double momentum)
        {
            for(int i = 0; i<layers.size(); i++)
            {
                layers.get(i).updateWeights(learningRate, momentum);
            }
        }

        public ArrayList<Double> predict(ArrayList<Double> x)
        {
            return this.forward(x);
        }

        public void fit(ArrayList<ArrayList<Double>> X, ArrayList<ArrayList<Double>> Y, double learningRate, double momentum, int nb_epochs)
        {
            double total_loss = 0.0;
            
            System.out.println("POZVAO SA "+ nb_epochs);
            for (int n = 0; n < nb_epochs; n++)
            {
                System.out.println("--- : " + n);
                for (int i = 0; i < X.size(); i++)
                {
                    ArrayList<Double> x = X.get(i);
                    ArrayList<Double> y = Y.get(i);
                    ArrayList<Double> predicted = this.forward(x);
                    double grad = 0.0;

                    for (int j = 0; j < predicted.size(); j++)
                    {
                        double output = predicted.get(j);
                        double target = y.get(j);
                        //opadajuci gradijent
                        total_loss += Math.pow((target - 0), 2);
                        grad += -(target - output);
                    }
                    ArrayList<ArrayList<Double>> gradient = new ArrayList<ArrayList<Double>>();
                    ArrayList<Double> pom = new ArrayList<Double>() ;
                    pom.add(grad);
                    gradient.add(pom);
                   

                    this.backward(gradient);
                    this.updateWeights(learningRate, momentum);
                }
            }
        }
        
    }
