package neural;
import java.util.ArrayList;
import neural.NeuronNode;


    public class NeuralLayer
    {
        public int n_inputs;
        public int n_neurons;
        public String activation;
        public ArrayList<NeuronNode> neurons;

        public NeuralLayer(int n_inputs, int n_neurons, String activation)
        {
            this.n_inputs = n_inputs;
            this.n_neurons = n_neurons;
            this.activation = activation;
            this.neurons = new ArrayList<NeuronNode>();

            for (int i = 0; i < n_neurons; i++)
            {
                NeuronNode neuron = new NeuronNode(n_inputs, activation);
                this.neurons.add(neuron);

            }
        }

        public ArrayList<Double> forward(ArrayList<Double> x)
        {
            ArrayList<Double> layer_output = new ArrayList<Double>();
            
           for(int i = 0; i < this.neurons.size();++i)
           {
               double neuron_output = this.neurons.get(i).forward(x);
                layer_output.add(neuron_output);
           }
            /*foreach (var neuron in this.neurons)
            {
                double neuron_output = neuron.forward(x);
                layer_output.Add(neuron_output);
            }*/

            return layer_output;
        }

        /// <summary>
        /// Propagacija backward signala kroz sve neurone u sloju
        /// </summary>
        /// <param name="dz">dz is a vector of "n_neurons" elements</param>
        /// <returns></returns>
        public ArrayList<ArrayList<Double>> backward(ArrayList<ArrayList<Double>> dz)
        {//a vidi sta je, on posalje tek kreiran taj niz nizova, nista u njemu, kad je u else
            if(dz.size() != 0){
            ArrayList<ArrayList<Double>> backward_signal = new ArrayList<ArrayList<Double>>();
            for (int i = 0; i < this.neurons.size(); i++)
            {
                
                ArrayList<Double> neuron_dz = new ArrayList<Double>();
                for(int j = 0; j < dz.get(0).size();++j)
                {
                     neuron_dz.add(dz.get(0).get(j));
                }
               //List<double> neuron_dz = dz.Select(d => d[i]).ToList(); // selekcija i-te vrste u matrici//hmmm, ja sam taj framework uzeo od nekog resen :D, tako da blage nemam sta je ovo d :D
               neuron_dz = neurons.get(i).backward(neuron_dz);
               ArrayList<Double> pom = new ArrayList<Double>();
               for(int j = 0; j < neuron_dz.size()-1;++j)
               {
                   pom.add(neuron_dz.get(j));//u to ide lista
               }
               backward_signal.add(pom);
               //backward_signal.Add(neuron_dz.Take(neuron_dz.Count - 1).ToList());//sve osim poslednjeg zbog biasa
            }
            return backward_signal;
            }
            else return new ArrayList<ArrayList<Double>>();
            
        }
        /// <summary>
        /// Koriguj tezine svih neurona
        /// </summary>
        /// <param name="learningRate"></param>
        /// <param name="momentum"></param>
        public void updateWeights(double learningRate, double momentum)
        {   //TODO 8: koriguj tezine svih neurona
            
            for(int i = 0; i < neurons.size();++i)
            {
                neurons.get(i).updateWeights(learningRate, momentum);
            }
            //neurons.ForEach(neuron => neuron.updateWeights(learningRate, momentum));
        }
    }

