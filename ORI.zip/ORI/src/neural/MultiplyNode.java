/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neural;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tijana-PC
 */

    public class MultiplyNode
    {
        //niz koji sadrzi ulaz i tezinu
        //prvi element je ulaz, a drugi njegova tezina
        public ArrayList<Double> x;

        public MultiplyNode()
        {
            x = new ArrayList<Double>();
            x.add(0.0);
            x.add(0.0);
        }
        /// <summary>
        /// Mnozenje ulaza sa tezinom
        /// </summary>
        /// <param name="x"></param>
        /// <returns>Proizvod ulaza i tezine</returns>
        public double forward(ArrayList<Double> x)
        {
            this.x = x;
            return this.x.get(0) * this.x.get(1);
        }

        /// <summary>
        /// z = x*y 
        /// dz/dx = y => dx = dz*y
        /// dz/dy = x => dy = dz*x
        /// </summary>
        /// <param name="dz">izvod </param>
        /// <returns>[dx, dy]</returns>
        public ArrayList<Double> backward(double dz)
        {
            double[] retval = { this.x.get(1) * dz, this.x.get(0) * dz };
            ArrayList<Double> lista = new ArrayList<Double>();
            for(int i = 0; i < retval.length; i++) lista.add(retval[i]);
            return lista;
        }
    }

