/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neural;

/**
 *pogledacu ujutru, ajde na spavanje, treba web da radimo sutra citav dan, posalji mi samo ovako na fb zipovan proj ako ustanem ranije ko obicno
 * @author Tijana-PC
 */
 public class SigmoidNode
    {
        private double x;
        /// <summary>
        /// Sigmoid funkcija 1/1+e^-x
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        private double sigmoid(double x)  //samo sigm fja
        {
            // TODO 5.1: Implementirati forward korak sigmoidnog cvora
            double sigm_retVal = 0.0;

            sigm_retVal = 1 / (1 + Math.exp(-x));

            return sigm_retVal;
        }

        public SigmoidNode()
        {
            this.x = 0;
        }

        /// <summary>
        /// Na dobijeno x pozvati sigmoid funkciju
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public double forward(double x)
        {
            this.x = x;
            return this.sigmoid(this.x);
        }

        /// <summary>
        /// z = 1/1+e^-x
        /// dz/dx = sigm(x)*(1-sigm(x))
        /// =>dx = dz * sigm(x)*(1-sigm(x))
        /// </summary>
        /// <param name="dz"></param>
        /// <returns></returns>
        public double backward(double dz)
        {
            // TODO 5.2: Implementirati backward korak sigmoidog cvora
            double retVal = 0.0;

            retVal = dz * this.sigmoid(this.x) * (1 - this.sigmoid(this.x));

            return retVal;
        }


    }
