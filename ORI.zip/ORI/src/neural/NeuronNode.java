/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neural;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Tijana-PC
 */
   public class NeuronNode
    {
        public int n_inputs;
        public ArrayList<MultiplyNode> multiplyNodes;
        public SumNode sumNode;
        public SigmoidNode activation_node;
        public ArrayList<Double> previous_deltas;
        public ArrayList<ArrayList<Double>> gradients;
        private Random rnd = new Random();

    public int getN_inputs() {
        return n_inputs;
    }

    public void setN_inputs(int n_inputs) {
        this.n_inputs = n_inputs;
    }

        
        /// <summary>
        /// https://en.wikipedia.org/wiki/Artificial_neuron
        /// ulaz1*tezina1
        /// ulaz1*tezina2
        /// bias(+1*tezina)
        /// sve se sabere
        /// provuce se kroz aktivacionu funkciju
        /// </summary>
        /// <param name="n_inputs"></param>
        /// <param name="activation"></param>
        public NeuronNode(int n_inputs, String activation)
        {
            this.n_inputs = n_inputs;
            this.multiplyNodes = new ArrayList<MultiplyNode>(); //for inputs and weights
            this.sumNode = new SumNode();                  //for sum of inputs*weights
            this.previous_deltas = new ArrayList<Double>();     //vrednost delti u prosloj iteraciji
            this.gradients = new ArrayList<ArrayList<Double>>();     //lokalni gradijenti
            MultiplyNode mulNode;
            
            //init inputs
            //collect inputs and corresponding weights
            for (int i = 0; i < this.n_inputs; i++)
            {
                mulNode = new MultiplyNode();
                mulNode.x = new ArrayList<Double>(); //{ 1.0, (rnd.next() - 0.5) / 50.0 };//izemdju -0.1 i 0.1
                mulNode.x.add(1.0); mulNode.x.add((rnd.nextDouble()-0.5)/50.0);
                this.multiplyNodes.add(mulNode);
                previous_deltas.add(0.0);
            }

            //init bias node and weight
            mulNode = new MultiplyNode();
                            mulNode.x = new ArrayList<Double>(); //{ 1.0, (rnd.next() - 0.5) / 50.0 };//izemdju -0.1 i 0.1
                mulNode.x.add(1.0); mulNode.x.add((rnd.nextDouble()-0.5)/50.0);
            this.multiplyNodes.add(mulNode);
            previous_deltas.add(0.0);

            if (activation.equals("sigmoid"))
                this.activation_node = new SigmoidNode();
            else
                System.out.println("Activation function is not supported");

        }
        /// <summary>
        /// Pomnoziti sve ulaze sa tezinama.
        /// Sabrati sve rezultate mnozaca. Kao povratnu vrednost
        /// vratiti vrednost aktivacione funkije za vrednost suma 
        /// svih mnozaca
        /// </summary>
        /// <param name="x">x is a vector of inputs</param>
        /// <returns></returns>
        public double forward(ArrayList<Double> x)
        {
            ArrayList<Double> inputs = new ArrayList<Double>(x);
            inputs.add(1.0); //bias

            ArrayList<Double> forSum = new ArrayList<Double>();
            for (int i = 0; i < inputs.size(); i++)
            {
                double[] inp_d = new double[2];
                inp_d[0] = inputs.get(i);
                inp_d[1] = this.multiplyNodes.get(i).x.get(1); 
                ArrayList<Double> pom2 = new ArrayList<Double>();
                pom2.add(inp_d[0]); pom2.add(inp_d[1]);
                forSum.add(this.multiplyNodes.get(i).forward(pom2));
            }

            double summed = this.sumNode.forward(forSum);

            // dobijena vrednost se propusti kroz aktivacionu funkciju
            double summed_act = this.activation_node.forward(summed);
            return summed_act;
        }

        /// <summary>
        /// Greska se propagira u nazad kroz aktivacionu funkciju,
        /// preko sabiraca, do svakog pojedinacnog mnozaca
        /// </summary>
        /// <param name="dz"></param>
        /// <returns></returns>
        public ArrayList<Double> backward(ArrayList<Double> dz)
        {
            //greska svakog ulaza
            ArrayList<Double> dw = new ArrayList<Double>();
            double sum = 0; 
            for(int i = 0; i < dz.size(); i++) sum+=dz.get(i);
            double backward_signal = sum;
            backward_signal = this.activation_node.backward(backward_signal);
            ArrayList<Double> dSum = this.sumNode.backward(backward_signal);
            for (int i = 0; i < dSum.size(); i++)
            {
                dw.add(this.multiplyNodes.get(i).backward(dSum.get(i)).get(1));
            }

            //https://en.wikipedia.org/wiki/Gradient_descent
            //df/dx1, df/dx2...
            this.gradients.add(dw);

            return dw;
        }

        public void updateWeights(double learning_rate, double momentum)
        {
            for (int i = 0; i < multiplyNodes.size(); i++)
            {
                double sum = 0;
                ArrayList<Double> pom = new ArrayList<Double>();
                for(int j = 0; j < this.gradients.get(0).size(); j++)
                {
                    pom.add(this.gradients.get(0).get(j));
                    sum+=this.gradients.get(0).get(j);
                }
                //ArrayList<Double> grad = this.gradients.Select(gradient => gradient[i]).ToList();
                double meanGradient = sum / this.gradients.size();
                double delta = learning_rate * meanGradient + momentum * this.previous_deltas.get(i);
                this.previous_deltas.set(i,delta);
                //this.multiplyNodes[i].x[1] -= delta; //koriguj tezine 
                double xc = this.multiplyNodes.get(i).x.get(1) -delta;
                this.multiplyNodes.get(i).x.set(1, xc);
            }
            //reset gradijenata
            this.gradients.clear();
        }
    }
