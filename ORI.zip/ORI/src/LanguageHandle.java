/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Marko
 */
public class LanguageHandle {
    private String infoMessage1EN = "Creators of this software are Marko Tagliavia and Tijana Lalosevic";
    private String infoMessage2EN = "This software is designed to calculate possibility of tips for Barclays Premier League matches.\n"
            + " Possibilitys are calculated based on results beetween two selected teams in past years, and NOT based on free evalue of teams quality. ";
    private String infoMessage3EN = "1. Select team1 (HOME TEAM) from combo box 1 (left cb)\n"
            + "2. Select team2 (AWAY TEAM) from combo box 2 (right cb)\n"
            + "3. Click Calculate button or click Options from menu bar and then menu item Calculate or pres CTRL+S on your keyboard\n"
            + "4. If you want to reset to begin, click Options from menu bar and then menu item Reset\n"
            + "5. If yout want to change the software language click Language from menu bar and then pick language\n"
            + "6. If you want to close software, click on X button in top right corner or click Options from menu bar and then menu item Exit\n"
            + "7. If you want to change method for calculating, click Method from menu bar and then select method you want\n"
            + "8. If you want to change parametars for methods and see the best parametars, click Options from menu bar and then Parametars\n"
            + "9. If you want to update database, click Update database from menu bar";
    
    private String infoMessage1SRB = "Ovaj program su napravili napravili Marko Tagliavia i Tijana Lalosevic";
    private String infoMessage2SRB = "Ovaj program je dizajniran da izracunava verovatnoce kladionicarskih tipova utakmica Barclays Premier Lige.\n"
            + "Verovatnoce su racunate na osnovu rezultata izmedju dve oznacene ekipe u proslim godinama, i NE na osnovu slobodne procene kvaliteta ekipa.";
    private String infoMessage3SRB = "1. Selektujte prvi tim (DOMACI) iz padajuceg menija sa leve strane\n"
            + "2. Selektujte drugi tim (GOSTUJUCI) iz padajuceg menija sa desne strane\n"
            + "3. Kliknite na dugme Izracunaj ili kliknite na Opcije u meniju i zatim Izracunaj ili CTRL+S na tastaturi\n"
            + "4. Ako zelite da vratite na pocetna podesavanja kliknite na Opcije u meniju i zatim Resetuj\n"
            + "5. Ako zelite da promenite jezik programa kliknite na Jezik u meniju i zatim odaberite jezik\n"
            + "6. Ako zelite da zatvorite program, kliknite na X u gornjem desnom delu prozora ili kliknite na Opcije u meniju i zatim Izlaz\n"
            + "7. Ako zelite da promenite metodu za izracunavanje, kliknite Metode u meniju i izaberite metodu koju zelite\n"
            + "8. Ako zelite da promenite parametre metoda i vidite koji su najbolji, kliknite Opcije u meniju i izaberite Parametri\n"
            + "9. Ako zelite da azurirate bazu podataka, kliknite Azuriraj bazu u meniju";
    
    private String info_default1 = infoMessage1EN;
    private String info_default2 = infoMessage2EN;
    private String info_default3 = infoMessage3EN;
    
    private String pop1EN = "Creator";
    private String pop2EN = "About";
    private String pop3EN = "User manual";
    
    private String pop1SRB = "Autor";
    private String pop2SRB = "O aplikaciji";
    private String pop3SRB = "Uputstvo za korisnike";
    
    private String pop_default1 = pop1EN;
    private String pop_default2 = pop2EN;
    private String pop_default3 = pop3EN;
    
    private String same_sidesEN = "SAME TEAMS!";
    private String same_sidesSRB = "ISTE EKIPE!";
    
    private String same_sides_default = same_sidesEN;

    private String nisu_igrali2SRB = "Ova dva tima jos nisu igrala jedan protiv drugog!";
    private String nisu_igrali2EN = "This two teams have not played against each other yet!";
    
    private String nisu_igrali2_default = nisu_igrali2EN;
    
    private String nisu_igrali1SRB = "Upozorenje";
    private String nisu_igrali1EN = "Warning";
    
    private String nisu_igrali1_default = nisu_igrali1EN;
    
    private String LaG_EN = "La-Grange Interpolation";
    private String LaG_SRB = "La-Granzova Interpolacija";
    private String LaG_default = LaG_EN;

    private String Reg_EN = "Regression";
    private String Reg_SRB = "Regresija";
    private String Reg_default = Reg_EN;
    
    private String Met_EN = "Method";
    private String Met_SRB = "Metoda";
    private String Met_default = Met_EN;
    
    private String Bad_c_EN = "No connection! Old version of database will be used";
    private String Bad_c_SRB = "Nema konekcije! bice iskoristena poslednja verzija baze";
    private String Bad_c = Bad_c_EN;
    
    
    public String getInfoMessage1EN() {
        return infoMessage1EN;
    }

    public void setInfoMessage1EN(String infoMessage1EN) {
        this.infoMessage1EN = infoMessage1EN;
    }

    public String getInfoMessage2EN() {
        return infoMessage2EN;
    }

    public void setInfoMessage2EN(String infoMessage2EN) {
        this.infoMessage2EN = infoMessage2EN;
    }

    public String getInfoMessage3EN() {
        return infoMessage3EN;
    }

    public void setInfoMessage3EN(String infoMessage3EN) {
        this.infoMessage3EN = infoMessage3EN;
    }

    public String getInfoMessage1SRB() {
        return infoMessage1SRB;
    }

    public void setInfoMessage1SRB(String infoMessage1SRB) {
        this.infoMessage1SRB = infoMessage1SRB;
    }

    public String getInfoMessage2SRB() {
        return infoMessage2SRB;
    }

    public void setInfoMessage2SRB(String infoMessage2SRB) {
        this.infoMessage2SRB = infoMessage2SRB;
    }

    public String getInfoMessage3SRB() {
        return infoMessage3SRB;
    }

    public void setInfoMessage3SRB(String infoMessage3SRB) {
        this.infoMessage3SRB = infoMessage3SRB;
    }

    public String getInfo_default1() {
        return info_default1;
    }

    public void setInfo_default1(String info_default1) {
        this.info_default1 = info_default1;
    }

    public String getInfo_default2() {
        return info_default2;
    }

    public void setInfo_default2(String info_default2) {
        this.info_default2 = info_default2;
    }

    public String getInfo_default3() {
        return info_default3;
    }

    public void setInfo_default3(String info_default3) {
        this.info_default3 = info_default3;
    }

    public String getPop1EN() {
        return pop1EN;
    }

    public void setPop1EN(String pop1EN) {
        this.pop1EN = pop1EN;
    }

    public String getPop2EN() {
        return pop2EN;
    }

    public void setPop2EN(String pop2EN) {
        this.pop2EN = pop2EN;
    }

    public String getPop3EN() {
        return pop3EN;
    }

    public void setPop3EN(String pop3EN) {
        this.pop3EN = pop3EN;
    }

    public String getPop1SRB() {
        return pop1SRB;
    }

    public void setPop1SRB(String pop1SRB) {
        this.pop1SRB = pop1SRB;
    }

    public String getPop2SRB() {
        return pop2SRB;
    }

    public void setPop2SRB(String pop2SRB) {
        this.pop2SRB = pop2SRB;
    }

    public String getPop3SRB() {
        return pop3SRB;
    }

    public void setPop3SRB(String pop3SRB) {
        this.pop3SRB = pop3SRB;
    }

    public String getPop_default1() {
        return pop_default1;
    }

    public void setPop_default1(String pop_default1) {
        this.pop_default1 = pop_default1;
    }

    public String getPop_default2() {
        return pop_default2;
    }

    public void setPop_default2(String pop_default2) {
        this.pop_default2 = pop_default2;
    }

    public String getPop_default3() {
        return pop_default3;
    }

    public void setPop_default3(String pop_default3) {
        this.pop_default3 = pop_default3;
    }

    public String getSame_sidesEN() {
        return same_sidesEN;
    }

    public void setSame_sidesEN(String same_sidesEN) {
        this.same_sidesEN = same_sidesEN;
    }

    public String getSame_sidesSRB() {
        return same_sidesSRB;
    }

    public void setSame_sidesSRB(String same_sidesSRB) {
        this.same_sidesSRB = same_sidesSRB;
    }

    public String getSame_sides_default() {
        return same_sides_default;
    }

    public void setSame_sides_default(String same_sides_default) {
        this.same_sides_default = same_sides_default;
    }

    public String getNisu_igrali2SRB() {
        return nisu_igrali2SRB;
    }

    public void setNisu_igrali2SRB(String nisu_igrali2SRB) {
        this.nisu_igrali2SRB = nisu_igrali2SRB;
    }

    public String getNisu_igrali2EN() {
        return nisu_igrali2EN;
    }

    public void setNisu_igrali2EN(String nisu_igrali2EN) {
        this.nisu_igrali2EN = nisu_igrali2EN;
    }

    public String getNisu_igrali2_default() {
        return nisu_igrali2_default;
    }

    public void setNisu_igrali2_default(String nisu_igrali2_default) {
        this.nisu_igrali2_default = nisu_igrali2_default;
    }

    public String getNisu_igrali1SRB() {
        return nisu_igrali1SRB;
    }

    public void setNisu_igrali1SRB(String nisu_igrali1SRB) {
        this.nisu_igrali1SRB = nisu_igrali1SRB;
    }

    public String getNisu_igrali1EN() {
        return nisu_igrali1EN;
    }

    public void setNisu_igrali1EN(String nisu_igrali1EN) {
        this.nisu_igrali1EN = nisu_igrali1EN;
    }

    public String getNisu_igrali1_default() {
        return nisu_igrali1_default;
    }

    public void setNisu_igrali1_default(String nisu_igrali1_default) {
        this.nisu_igrali1_default = nisu_igrali1_default;
    }

    public String getLaG_EN() {
        return LaG_EN;
    }

    public String getLaG_SRB() {
        return LaG_SRB;
    }

    public String getLaG_default() {
        return LaG_default;
    }

    public String getReg_EN() {
        return Reg_EN;
    }

    public String getReg_SRB() {
        return Reg_SRB;
    }

    public String getReg_default() {
        return Reg_default;
    }

    public String getMet_EN() {
        return Met_EN;
    }

    public void setMet_EN(String Met_EN) {
        this.Met_EN = Met_EN;
    }

    public String getMet_SRB() {
        return Met_SRB;
    }

    public void setMet_SRB(String Met_SRB) {
        this.Met_SRB = Met_SRB;
    }

    public String getMet_default() {
        return Met_default;
    }

    public void setMet_default(String Met_default) {
        this.Met_default = Met_default;
    }

    public String getBad_c_EN() {
        return Bad_c_EN;
    }

    public void setBad_c_EN(String Bad_c_EN) {
        this.Bad_c_EN = Bad_c_EN;
    }

    public String getBad_c_SRB() {
        return Bad_c_SRB;
    }

    public void setBad_c_SRB(String Bad_c_SRB) {
        this.Bad_c_SRB = Bad_c_SRB;
    }

    public String getBad_c() {
        return Bad_c;
    }

    public void setBad_c(String Bad_c) {
        this.Bad_c = Bad_c;
    }

    public void setLaG_default(String LaG_default) {
        this.LaG_default = LaG_default;
    }

    public void setReg_default(String Reg_default) {
        this.Reg_default = Reg_default;
    }

    
    
    
}
