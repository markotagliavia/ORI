
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tijana-PC
 */
public class RandomForrest {
    
    
    private List<String> niz_kod;       
    private List<Integer> niz_gh; 
    private List<Integer> niz_ga;        //lista datih golova gosta
    private List<String> niz_home;        //lista imena domacina
    private List<String> niz_away;        //lista imena gostiju
    private List<Integer> niz_goloviHpoluvreme;        //lista datih golova domacina
    private List<Integer> niz_goloviApoluvreme;        //lista datih golova gosta
    private List<Integer> niz_suteviH;        //lista imena domacina
    private List<Integer> niz_suteviA;        //lista imena gostiju
    private List<Integer> niz_suteviOkvirH;        //lista datih golova domacina
    private List<Integer> niz_suteviOkvirA;        //lista datih golova gosta
    private List<Integer>  niz_korneH;        //lista datih golova domacina
    private List<Integer> niz_korneA;        //lista datih golova gosta
    private List<Integer> niz_zutiH;        //lista datih golova domacina
    private List<Integer> niz_zutiA;        //lista datih golova gosta
    private List<Integer> niz_crveniH;        //lista datih golova domacina
    private List<Integer> niz_crveniA;        //lista datih golova gosta
    private List<Integer> niz_faulH;        //lista datih golova domacina
    private List<Integer> niz_faulA;        //lista datih golova gosta
    
    private List<Double> niz_kvoteH;
    private List<Double> niz_kvoteX;
    private List<Double> niz_kvoteA;
    
    private List<String> niz_sudije;
    
    private List<Integer> rez; //upisujem rezultate
    
    public RandomForrest(List<String> niz_kod, List<Integer> niz_gh, List<Integer> niz_ga, List<String> niz_home, List<String> niz_away, List<Integer> niz_goloviHpoluvreme, List<Integer> niz_goloviApoluvreme, List<Integer> niz_suteviH, List<Integer> niz_suteviA, List<Integer> niz_suteviOkvirH, List<Integer> niz_suteviOkvirA, List<Integer> niz_korneH, List<Integer> niz_korneA, List<Integer> niz_zutiH, List<Integer> niz_zutiA, List<Integer> niz_crveniH, List<Integer> niz_crveniA, List<Integer> niz_faulH, List<Integer> niz_faulA, List<Double> niz_kvoteH, List<Double> niz_kvoteX, List<Double> niz_kvoteA, List<String> niz_sudije){
        
        this.niz_kod = niz_kod;
        this.niz_gh = niz_gh;
        this.niz_ga = niz_ga;
        this.niz_home = niz_home;
        this.niz_away = niz_away;
        this.niz_goloviHpoluvreme = niz_goloviHpoluvreme;
        this.niz_goloviApoluvreme = niz_goloviApoluvreme;
        this.niz_suteviH = niz_suteviH;
        this.niz_suteviA = niz_suteviA;
        this.niz_suteviOkvirH = niz_suteviOkvirH;
        this.niz_suteviOkvirA = niz_suteviOkvirA;
        this.niz_korneH = niz_korneH;
        this.niz_korneA = niz_korneA;
        this.niz_zutiH = niz_zutiH;
        this.niz_zutiA = niz_zutiA;
        this.niz_crveniH = niz_crveniH;
        this.niz_crveniA = niz_crveniA;
        this.niz_faulH = niz_faulH;
        this.niz_faulA = niz_faulA;
        this.niz_kvoteH = niz_kvoteH;
        this.niz_kvoteA = niz_kvoteA;
        this.niz_kvoteX = niz_kvoteX;
        this.niz_sudije = niz_sudije;
        this.rez = new ArrayList<Integer>();
    }
    
    public int result(String domaci, String gosti, int n) //praviti da nije moduo 0 od 3
    {
    
        for(int i = 0; i < n; ++i)
        {
            Random random = new Random();
            
            
            
            int rnd = random.nextInt(10);
            int ishod = 404;
            
            int utakmica1 = random.nextInt(niz_gh.size());
            int utakmica2 = random.nextInt(niz_gh.size());
            
            switch(rnd){
            
                case 0:  
                    ishod = racunajRazlika(domaci,gosti,utakmica1,utakmica2);
                        break;
                case 1:
                    ishod = racunajSutevi(domaci,gosti,utakmica1,utakmica2);
                        break;
                case 2:
                    ishod = racunajOkvir(domaci,gosti,utakmica1,utakmica2);
                        break;
                case 3:
                    ishod = racunajKvota(domaci,gosti,utakmica1,utakmica2);
                        break;
                case 4:
                    ishod = racunajSudije(domaci,gosti,utakmica1,utakmica2);
                        break;
                case 5:
                    ishod = racunajKorner(domaci,gosti,utakmica1,utakmica2);
                        break;
                default:
            }
        
        
            rez.add(ishod);
        
        }
        
        int brojac1 = 0;
        int brojacX = 0;
        int brojac2 = 0;
        for(int j = 0; j < rez.size(); j++)
        {
            if(rez.get(j) == 1) brojac1++;
            else if(rez.get(j) == 0) brojacX++;
            else brojac2++;
        }
        
        if(brojac1 > brojacX && brojac1 > brojac2) return 1;
        else if(brojacX > brojac1 && brojacX > brojac2) return 0;
        else if(brojac2 > brojacX && brojac2 > brojac1) return 2;
        else return 0;
    }
    
    public int racunajRazlika(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
        
        int goldom = 0;
        
        int golgost = 0;
        
        
        if(niz_home.get(utakmica1).equals(domaci))
        {
            if(niz_gh.get(utakmica1)>niz_ga.get(utakmica1))
            {
                ++goldom;
            }
            else if(niz_gh.get(utakmica1)<niz_ga.get(utakmica1))
            {
                ++golgost;
            }
        }
        else
        {
            if(niz_gh.get(utakmica1)>niz_ga.get(utakmica1))
            {
                ++golgost;
                
            }
            else if(niz_gh.get(utakmica1)<niz_ga.get(utakmica1))
            {
                ++goldom;
            }
        }
        
        
        
        
        if(niz_home.get(utakmica2).equals(domaci))
        {
            if(niz_gh.get(utakmica2)>niz_ga.get(utakmica2))
            {
                ++goldom;
            }
            else if(niz_gh.get(utakmica2)<niz_ga.get(utakmica2))
            {
                ++golgost;
            }
        }
        else
        {
            if(niz_gh.get(utakmica2)>niz_ga.get(utakmica2))
            {
                ++golgost;
                
            }
            else if(niz_gh.get(utakmica2)<niz_ga.get(utakmica2))
            {
                ++goldom;
            }
        }
        
        if(goldom > golgost)
        {
            rezultat = 1;
        }
        else if(goldom < golgost)
        {
            rezultat = 2;
        }
    
    
        return rezultat;
    }
    
    public int racunajSutevi(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
        
        int sutdom = 0;
        
        int sutgost = 0;
        
        
        if(niz_home.get(utakmica1).equals(domaci))
        {
            if(niz_suteviH.get(utakmica1)>niz_suteviA.get(utakmica1))
            {
                ++sutdom;
            }
            else if(niz_suteviH.get(utakmica1)<niz_suteviA.get(utakmica1))
            {
                ++sutgost;
            }
        }
        else
        {
            if(niz_suteviH.get(utakmica1)>niz_suteviA.get(utakmica1))
            {
                ++sutgost;
                
            }
            else if(niz_suteviH.get(utakmica1)<niz_suteviA.get(utakmica1))
            {
                ++sutdom;
            }
        }
        
        
        
        
        if(niz_home.get(utakmica2).equals(domaci))
        {
            if(niz_suteviH.get(utakmica2)>niz_suteviA.get(utakmica2))
            {
                ++sutdom;
            }
            else if(niz_suteviH.get(utakmica2)<niz_suteviA.get(utakmica2))
            {
                ++sutgost;
            }
        }
        else
        {
            if(niz_suteviH.get(utakmica2)>niz_suteviA.get(utakmica2))
            {
                ++sutgost;
                
            }
            else if(niz_suteviH.get(utakmica2)<niz_suteviA.get(utakmica2))
            {
                ++sutdom;
            }
        }
        
        if(sutdom > sutgost)
        {
            rezultat = 1;
        }
        else if(sutdom < sutgost)
        {
            rezultat = 2;
        }
    
    
        return rezultat;
    }
    
    public int racunajOkvir(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
    
        int sutdom = 0;
        
        int sutgost = 0;
        
        
        if(niz_home.get(utakmica1).equals(domaci))
        {
            if(niz_suteviOkvirH.get(utakmica1)>niz_suteviOkvirA.get(utakmica1))
            {
                ++sutdom;
            }
            else if(niz_suteviOkvirH.get(utakmica1)<niz_suteviOkvirA.get(utakmica1))
            {
                ++sutgost;
            }
        }
        else
        {
            if(niz_suteviOkvirH.get(utakmica1)>niz_suteviOkvirA.get(utakmica1))
            {
                ++sutgost;
                
            }
            else if(niz_suteviOkvirH.get(utakmica1)<niz_suteviOkvirA.get(utakmica1))
            {
                ++sutdom;
            }
        }
        
        
        
        
        if(niz_home.get(utakmica2).equals(domaci))
        {
            if(niz_suteviOkvirH.get(utakmica2)>niz_suteviOkvirA.get(utakmica2))
            {
                ++sutdom;
            }
            else if(niz_suteviOkvirH.get(utakmica2)<niz_suteviOkvirA.get(utakmica2))
            {
                ++sutgost;
            }
        }
        else
        {
            if(niz_suteviOkvirH.get(utakmica2)>niz_suteviOkvirA.get(utakmica2))
            {
                ++sutgost;
                
            }
            else if(niz_suteviOkvirH.get(utakmica2)<niz_suteviOkvirA.get(utakmica2))
            {
                ++sutdom;
            }
        }
        
        if(sutdom > sutgost)
        {
            rezultat = 1;
        }
        else if(sutdom < sutgost)
        {
            rezultat = 2;
        }
        
        return rezultat;
    }
    
    public int racunajKvota(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
        
        int kvotadom = 0;
        
        int kvotagost = 0;
        
        
        if(niz_home.get(utakmica1).equals(domaci))
        {
            if(niz_suteviOkvirH.get(utakmica1)>niz_suteviOkvirA.get(utakmica1))
            {
                ++kvotadom;
            }
            else if(niz_suteviOkvirH.get(utakmica1)<niz_suteviOkvirA.get(utakmica1))
            {
                ++kvotagost;
            }
        }
        else
        {
            if(niz_suteviOkvirH.get(utakmica1)>niz_suteviOkvirA.get(utakmica1))
            {
                ++kvotagost;
                
            }
            else if(niz_suteviOkvirH.get(utakmica1)<niz_suteviOkvirA.get(utakmica1))
            {
                ++kvotadom;
            }
        }
        
        
        
        
        if(niz_home.get(utakmica2).equals(domaci))
        {
            if(niz_suteviOkvirH.get(utakmica2)>niz_suteviOkvirA.get(utakmica2))
            {
                ++kvotadom;
            }
            else if(niz_suteviOkvirH.get(utakmica2)<niz_suteviOkvirA.get(utakmica2))
            {
                ++kvotagost;
            }
        }
        else
        {
            if(niz_suteviOkvirH.get(utakmica2)>niz_suteviOkvirA.get(utakmica2))
            {
                ++kvotagost;
                
            }
            else if(niz_suteviOkvirH.get(utakmica2)<niz_suteviOkvirA.get(utakmica2))
            {
                ++kvotadom;
            }
        }
        
        if(kvotadom > kvotagost)
        {
            rezultat = 2;
        }
        else if(kvotadom < kvotagost)
        {
            rezultat = 1;
        }
    
    
        return rezultat;
    }
    
    public int racunajKorner(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
    
        int kornerdom = 0;
        
        int kornergost = 0;
        
        
        if(niz_home.get(utakmica1).equals(domaci))
        {
            if(niz_korneH.get(utakmica1)>niz_korneA.get(utakmica1))
            {
                ++kornerdom;
            }
            else if(niz_korneH.get(utakmica1)<niz_korneA.get(utakmica1))
            {
                ++kornergost;
            }
        }
        else
        {
            if(niz_korneH.get(utakmica1)>niz_korneA.get(utakmica1))
            {
                ++kornergost;
                
            }
            else if(niz_korneH.get(utakmica1)<niz_korneA.get(utakmica1))
            {
                ++kornerdom;
            }
        }
        
        
        
        
        if(niz_home.get(utakmica2).equals(domaci))
        {
            if(niz_korneH.get(utakmica2)>niz_korneA.get(utakmica2))
            {
                ++kornerdom;
            }
            else if(niz_korneH.get(utakmica2)<niz_korneA.get(utakmica2))
            {
                ++kornergost;
            }
        }
        else
        {
            if(niz_korneH.get(utakmica2)>niz_korneA.get(utakmica2))
            {
                ++kornergost;
                
            }
            else if(niz_korneH.get(utakmica2)<niz_korneA.get(utakmica2))
            {
                ++kornerdom;
            }
        }
        
        if(kornerdom > kornergost)
        {
            rezultat = 1;
        }
        else if(kornerdom < kornergost)
        {
            rezultat = 2;
        }
        
        return rezultat;
    }
    
    public int racunajSudije(String domaci,String gosti,int utakmica1,int utakmica2){
    
        int rezultat = 0;
        rezultat = dalVoleSudijaDomace(utakmica1, utakmica2);
        return rezultat;
    }
    
    public int dalVoleSudijaDomace(int utakmica1, int utakmica2)
   {
      int t = -1;
       HashMap<String, int[]> mapa = new HashMap<String, int[]>();
              Scanner fileIn = null;
		try {
			fileIn = new Scanner(new File("izlazSudije.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn.hasNext())
		{
			String line = fileIn.nextLine();
			String pom[] = line.split(",");
                        int[] niz = new int[3];
                        niz[0] = Integer.parseInt(pom[1]);
                        niz[1] = Integer.parseInt(pom[2]);
                        niz[2] = Integer.parseInt(pom[3]);
                        mapa.put(pom[0], niz);
                }
           
        int zbirDomaciPobede = 0;
        int zbirGostiPobede = 0;
        int zbirNereseno = 0;

               zbirDomaciPobede += mapa.get(niz_sudije.get(utakmica1))[0];
               zbirGostiPobede += mapa.get(niz_sudije.get(utakmica1))[2];
               zbirNereseno += mapa.get(niz_sudije.get(utakmica1))[1];

               zbirDomaciPobede += mapa.get(niz_sudije.get(utakmica2))[0];
               zbirGostiPobede += mapa.get(niz_sudije.get(utakmica2))[2];
               zbirNereseno += mapa.get(niz_sudije.get(utakmica2))[1];
               
       if(zbirDomaciPobede > zbirGostiPobede && zbirDomaciPobede > zbirNereseno) t = 1;
       else if(zbirGostiPobede > zbirDomaciPobede && zbirGostiPobede > zbirNereseno) t = 2;
       else t = 0;
                 
       return t;         
   }
    
    
}
