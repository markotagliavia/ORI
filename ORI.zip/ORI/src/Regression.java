/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kokoliko
 */
import static java.lang.Math.pow;
import Jama.Matrix;
public class Regression {
    
    
    double[] regresijaPolinom(double[] x,double[] y,int stepen)
    {
        double[]rezultat = new double[stepen];
    
        int duzina = x.length;
        int m = y.length;
        
        //double[][]values = new double[duzina][stepen+1];
        
        /*for(int i = 0; i < duzina; ++i)
            for(int j = 0; j < (stepen + 1); ++j)
                    values[i][j]=1;*/
        Matrix A = new Matrix(duzina,stepen+1,1);
        
        for(int i = 0; i < duzina; ++i)
        { 
            for(int j = 1; j < (stepen + 1); ++j)
            {  
                A.set(i, j,pow(x[i],(j)));
            }
        }
        
        double [][] yy = new double [1][m];
        
        for(int i = 0; i < m; ++i)
        { 
            yy[0][i] = y[i];
        }
        
        Matrix Y = new Matrix(yy);
        Matrix At,Yt,C,F,INV,REZ;
        At = A.transpose(); //transponovana A
        Yt = Y.transpose(); //transponovana Y
        C = At.times(A);
        F = At.times(Yt);
        //INV = F.inverse();
        //REZ = INV.times(C);
        REZ = C.solve(F);
        REZ = REZ.transpose();
        rezultat = REZ.getRowPackedCopy();
//C * REZ = F
  
        //f=(X'*X)\(X'*y');
   
        return rezultat;
    }
    
}
