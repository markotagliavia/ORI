
import java.awt.Color;
import java.awt.Component;
import static java.lang.Math.pow;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import neural.NeuralLayer;
import org.neuroph.core.NeuralNetwork;

import org.neuroph.core.learning.DataSet;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.util.TrainingSetImport;
import org.neuroph.util.TransferFunctionType;
/*import org.neuroph.core.NeuralNetwork;
import org.neuroph.core.learning.DataSet;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.util.TrainingSetImport;
import org.neuroph.util.TransferFunctionType;
*/


/**
 *
 * @author Marko, Tijana
 */
public class MyFrame extends javax.swing.JFrame {
        
    LanguageHandle l = new LanguageHandle();        //klasa za prevod
    FileManip f = new FileManip();                            //klasa za manipulaciju fajlom(upis, citanje)
    
    List<String> niz_kod = new ArrayList<String>();       //lista datuma
    List<Integer> niz_gh = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_ga = new ArrayList<Integer>();        //lista datih golova gosta
    List<String> niz_home = new ArrayList<String>();        //lista imena domacina
    List<String> niz_away = new ArrayList<String>();        //lista imena gostiju
    List<Integer> niz_goloviHpoluvreme = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_goloviApoluvreme = new ArrayList<Integer>();        //lista datih golova gosta
    List<Integer> niz_suteviH = new ArrayList<Integer>();        //lista imena domacina
    List<Integer> niz_suteviA = new ArrayList<Integer>();        //lista imena gostiju
    List<Integer> niz_suteviOkvirH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_suteviOkvirA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_korneH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_korneA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_zutiH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_zutiA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_crveniH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_crveniA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_faulH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_faulA = new ArrayList<Integer>();        //lista datih golova gosta
    
    List<Double> niz_kvoteH = new ArrayList<Double>();
    List<Double> niz_kvoteX = new ArrayList<Double>();
    List<Double> niz_kvoteA = new ArrayList<Double>();
    
    List<String> niz_sudije = new ArrayList<String>();
    
    List<String> niz_za_upis = new ArrayList<String>();     //lista koju saljem klasi File da upise torke iz baze u fajl
    
    List<Double> niz_MR = new ArrayList<Double>();        //niz MR
    double x[] = new double[68];                            //niz koji saljem funkciji LaG da nadje aproksimacioni polinom
    List<Integer> niz_MRHW = new ArrayList<Integer>();      //lista broja pobeda domacina za svaki MR
    List<Integer> niz_MRAW = new ArrayList<Integer>();      //lista broja neresenih za svaki MR
    List<Integer> niz_MRX = new ArrayList<Integer>();       //lista broja pobeda gosta za svaki MR
    boolean empty_query;                                    //prazan upit?
    int v=1;
    JLabel[] l1 = new JLabel[40];                            //labele na dnu panela koje se generisu za ispis rezultata i pregled
    int stepen = 2;
    int koef = 27;
   

    
    
    /**
     * Creates new form MyFrame
     */
    public MyFrame(){

            initComponents();
            initPanel();
            AddInGroup();
            AddInGroup1();
            int i = 0;
            //match rating
            
            Scanner sc = null;
        try {
            sc = new Scanner(new File("izlaz.txt"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MyFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            //INICIJALIZACIJA TABELE MR I BROJA POBEDA/NERESENIH/PORAZA
            while(sc.hasNext())
            {
                String line = sc.nextLine();
                String pom[] = line.split(",");
                double mr = Double.parseDouble(pom[0]);
                int a1 = Integer.parseInt(pom[1]);
                int a2 = Integer.parseInt(pom[2]);
                int a3 = Integer.parseInt(pom[3]);
                niz_MR.add(mr);
                niz_MRHW.add(a1);
                niz_MRX.add(a2);
                niz_MRAW.add(a3);
            }
            
            for(short i1 = 0; i1 < niz_MRHW.size(); i1++)
            {
                if(niz_MRHW.get(i1) == 0) {
                    niz_MRHW.set(i1, niz_MRHW.get(i1)+2);
                    niz_MRX.set(i1, niz_MRX.get(i1)+2);
                    niz_MRAW.set(i1, niz_MRAW.get(i1)+2);
                }
                x[i1] = niz_MR.get(i1);
            }
    }
    
     
     //izgenerisani layout
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jSeparator3 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem2 = new javax.swing.JRadioButtonMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jRadioButtonMenuItem3 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem4 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem5 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem6 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem7 = new javax.swing.JRadioButtonMenuItem();
        jRadioButtonMenuItem8 = new javax.swing.JRadioButtonMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("BPL Predictor");

        jPanel1.setBackground(new java.awt.Color(51, 204, 0));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 600));

        jLabel1.setText("HOME WIN");

        jLabel2.setText("DRAW");

        jLabel3.setText("AWAY WIN");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Arsenal", "Bournemouth", "Burnley", "Chelsea", "Crystal Palace", "Everton", "Hull", "Leicester", "Liverpool", "Man City", "Man United", "Middlesbrough", "Southampton", "Stoke", "Sunderland", "Swansea", "Tottenham", "Watford", "West Brom", "West Ham" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Arsenal", "Bournemouth", "Burnley", "Chelsea", "Crystal Palace", "Everton", "Hull", "Leicester", "Liverpool", "Man City", "Man United", "Middlesbrough", "Southampton", "Stoke", "Sunderland", "Swansea", "Tottenham", "Watford", "West Brom", "West Ham" }));
        jComboBox2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox2ItemStateChanged(evt);
            }
        });

        jButton1.setText("Calculate");
        jButton1.setToolTipText("");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png"))); // NOI18N

        jLabel6.setText("HOME");

        jLabel7.setText("AWAY");

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea1.setBackground(new java.awt.Color(51, 255, 0));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextArea1.setRows(5);
        jTextArea1.setAlignmentX(10.0F);
        jTextArea1.setAlignmentY(10.0F);
        jTextArea1.setDisabledTextColor(new java.awt.Color(255, 0, 0));
        jTextArea1.setEnabled(false);
        jScrollPane1.setViewportView(jTextArea1);

        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea2.setBackground(new java.awt.Color(51, 255, 0));
        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextArea2.setRows(5);
        jTextArea2.setDisabledTextColor(new java.awt.Color(255, 0, 0));
        jTextArea2.setEnabled(false);
        jScrollPane2.setViewportView(jTextArea2);

        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea3.setBackground(new java.awt.Color(51, 255, 0));
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextArea3.setRows(5);
        jTextArea3.setDisabledTextColor(new java.awt.Color(255, 0, 0));
        jTextArea3.setEnabled(false);
        jScrollPane3.setViewportView(jTextArea3);

        jPanel2.setBackground(new java.awt.Color(51, 204, 0));
        jPanel2.setAutoscrolls(true);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 142, Short.MAX_VALUE)
        );

        jScrollPane4.setViewportView(jPanel2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(126, 126, 126))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jLabel1)
                .addGap(212, 212, 212)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(107, 107, 107))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(199, 199, 199)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(185, 185, 185))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(153, 153, 153)
                        .addComponent(jButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel1.getAccessibleContext().setAccessibleName("Verry possible");

        jMenu1.setMnemonic(KeyEvent.VK_O);
        jMenu1.setText("Options");
        jMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu1ActionPerformed(evt);
            }
        });

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Calculate");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Reset");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);
        jMenu1.add(jSeparator4);

        jMenuItem8.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem8.setText("Statistics");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem8);

        jMenu6.setText("Parametars");

        jMenuItem9.setText("Regression (degree)");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem9);

        jMenuItem10.setText("NN Regression (k)");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem10);
        jMenu6.add(jSeparator5);

        jMenuItem11.setText("The best degree");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem11);

        jMenuItem12.setText("The best k");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem12);

        jMenu1.add(jMenu6);
        jMenu1.add(jSeparator1);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Exit");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        jMenu4.setText("Help");

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem4.setText("User manual");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem4);

        jMenuItem5.setText("About");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem5);
        jMenu4.add(jSeparator2);

        jMenuItem6.setText("Creator");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem6);

        jMenuBar1.add(jMenu4);

        jMenu3.setText("Language");
        jMenu3.setToolTipText("");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("English");
        jRadioButtonMenuItem1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButtonMenuItem1ItemStateChanged(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItem1);

        jRadioButtonMenuItem2.setText("Serbian");
        jRadioButtonMenuItem2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jRadioButtonMenuItem2ItemStateChanged(evt);
            }
        });
        jMenu3.add(jRadioButtonMenuItem2);

        jMenuBar1.add(jMenu3);

        jMenu5.setMnemonic('M');
        jMenu5.setText("Method");

        jRadioButtonMenuItem3.setSelected(true);
        jRadioButtonMenuItem3.setText("LaGrange Interpolation");
        jRadioButtonMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItem3ActionPerformed(evt);
            }
        });
        jMenu5.add(jRadioButtonMenuItem3);

        jRadioButtonMenuItem4.setText("Regression");
        jMenu5.add(jRadioButtonMenuItem4);

        jRadioButtonMenuItem5.setText("Nearest Neighbour Regression");
        jRadioButtonMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItem5ActionPerformed(evt);
            }
        });
        jMenu5.add(jRadioButtonMenuItem5);

        jRadioButtonMenuItem6.setSelected(true);
        jRadioButtonMenuItem6.setText("TreeDecision");
        jMenu5.add(jRadioButtonMenuItem6);

        jRadioButtonMenuItem7.setSelected(true);
        jRadioButtonMenuItem7.setText("Random Forest");
        jRadioButtonMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItem7ActionPerformed(evt);
            }
        });
        jMenu5.add(jRadioButtonMenuItem7);

        jRadioButtonMenuItem8.setSelected(true);
        jRadioButtonMenuItem8.setText("Neural Network");
        jMenu5.add(jRadioButtonMenuItem8);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 628, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //inicijalizujem layout za donji panel koji pokazuje utakmice i rezultate selektovanih timova
    void initPanel()
    {
                BoxLayout box=new BoxLayout(jPanel2,BoxLayout.Y_AXIS);
		//jPanel2.setBackground(Color.LIGHT_GRAY);
		jPanel2.setLayout(box);
		jPanel2.setAlignmentX(Component.CENTER_ALIGNMENT);
                
                for(int i = 0; i < 40; i++) 
                {
                        l1[i] = new JLabel("");
                        l1[i].setAlignmentX(Component.CENTER_ALIGNMENT);
                        jPanel2.add(l1[i]);
                        jPanel2.add(Box.createVerticalStrut(10));
                }
    }
    
    //cistim labele koje prikazuju rezultate na dnu frame-a
    void resetPanel()
    {
         for(int i = 0; i < 40; i++) l1[i].setText("");
    }
    
    public void Calculate()
    {
        int j = 0;      //broj tacnih poredjenja u bazi
        empty_query = false;
        //brisem stare vrednosti lista da ne bi imali preklapanje
                niz_kod.clear();
                niz_home.clear();
                niz_away.clear();
                niz_gh.clear();
                niz_ga.clear();
                niz_goloviHpoluvreme.clear();
                niz_goloviApoluvreme.clear();
                niz_suteviH.clear();
                niz_suteviA.clear();
                niz_suteviOkvirH.clear();
                niz_suteviOkvirA.clear();
                niz_korneH.clear();
                niz_korneA.clear();
                niz_zutiH.clear();
                  niz_zutiA.clear();
                  niz_crveniH.clear();
                niz_crveniA.clear();
                niz_sudije.clear();
                niz_kvoteH.clear();
                niz_kvoteX.clear();
                niz_kvoteA.clear();
                niz_faulH.clear();
                niz_faulA.clear();
                
        if(jComboBox1.getSelectedItem().toString().equals(jComboBox2.getSelectedItem().toString()))     //iste ekipe
        {
            jTextArea1.setText(l.getSame_sides_default());
            jTextArea2.setText(l.getSame_sides_default());
            jTextArea3.setText(l.getSame_sides_default());
        }else
        {
           Scanner sc2 = null;
            try {
                sc2 = new Scanner(new File("M2.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MyFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
           String[] s = new String[4180];
           int i3 = 0;
           while(sc2.hasNext())
           {
               s[i3++] = sc2.nextLine();
           }
            /*load selektovanih timova i podataka tih utakmica u nizove ali selekcija radi i obrnuto (zamenjen domacin i gost)*/
           //String[] s = f.loadText("M2.txt");
               String domacin = jComboBox1.getSelectedItem().toString();        //selektovan domacin
               String gost = jComboBox2.getSelectedItem().toString();              //selektovan gost

           for(int p = 0; p<s.length; p++)
           {
               //System.out.println(s[p]);
               String[] parts = s[p].split(",");                        //delim red iz txt fajla po zarezima da bih razdelio na vrednosti koje mi trebaju
               
               if((parts[2].equals(domacin) && parts[3].equals(gost)))      //poredim da li je selektovana bas ta torka baze (domacin i gost)
               {
                    niz_kod.add(parts[1]);
                    niz_home.add(parts[2]);
                    niz_away.add(parts[3]);
                    niz_gh.add(Integer.parseInt(parts[4]));
                    niz_ga.add(Integer.parseInt(parts[5]));
                    niz_goloviHpoluvreme.add(Integer.parseInt(parts[7]));
                    niz_goloviApoluvreme.add(Integer.parseInt(parts[8]));
                    niz_suteviH.add(Integer.parseInt(parts[11]));
                    niz_suteviA.add(Integer.parseInt(parts[12]));
                    niz_suteviOkvirH.add(Integer.parseInt(parts[13]));
                    niz_suteviOkvirA.add(Integer.parseInt(parts[14]));
                    niz_faulH.add(Integer.parseInt(parts[15]));
                    niz_faulA.add(Integer.parseInt(parts[16]));
                    niz_korneH.add(Integer.parseInt(parts[17]));
                    niz_korneA.add(Integer.parseInt(parts[18]));
                    niz_zutiH.add(Integer.parseInt(parts[19]));
                    niz_zutiA.add(Integer.parseInt(parts[20]));
                    niz_crveniH.add(Integer.parseInt(parts[21]));
                    niz_crveniA.add(Integer.parseInt(parts[22]));
                    niz_sudije.add(parts[10]);
                    niz_kvoteH.add(Double.parseDouble(parts[23]));
                    niz_kvoteX.add(Double.parseDouble(parts[24]));
                    niz_kvoteA.add(Double.parseDouble(parts[25]));
                    j++;                                                    //brojac koliko imam tacnih poredjenja torki
               }
               else if ((parts[3].equals(domacin) && parts[2].equals(gost)))    //poredim da li je selektovana bas ta torka baze (gost i domacin)
               {
                    niz_kod.add(parts[1]);
                    niz_home.add(parts[2]);
                    niz_away.add(parts[3]);
                    niz_gh.add(Integer.parseInt(parts[4]));
                    niz_ga.add(Integer.parseInt(parts[5]));
                    niz_goloviHpoluvreme.add(Integer.parseInt(parts[7]));
                    niz_goloviApoluvreme.add(Integer.parseInt(parts[8]));
                    niz_suteviH.add(Integer.parseInt(parts[11]));
                    niz_suteviA.add(Integer.parseInt(parts[12]));
                    niz_suteviOkvirH.add(Integer.parseInt(parts[13]));
                    niz_suteviOkvirA.add(Integer.parseInt(parts[14]));
                    niz_faulH.add(Integer.parseInt(parts[15]));
                    niz_faulA.add(Integer.parseInt(parts[16]));
                    niz_korneH.add(Integer.parseInt(parts[17]));
                    niz_korneA.add(Integer.parseInt(parts[18]));
                    niz_zutiH.add(Integer.parseInt(parts[19]));
                    niz_zutiA.add(Integer.parseInt(parts[20]));
                    niz_crveniH.add(Integer.parseInt(parts[21]));
                    niz_crveniA.add(Integer.parseInt(parts[22]));
                    niz_sudije.add(parts[10]);
                    niz_kvoteH.add(Double.parseDouble(parts[23]));
                    niz_kvoteX.add(Double.parseDouble(parts[24]));
                    niz_kvoteA.add(Double.parseDouble(parts[25]));
                    j++;               
               }

           }
           
           double mr = 0;       //inicijalno MR je 0
           double sum = 0;
            for(int k = 0; k<j; k++) 
            {
                //ispis utakmica koje su trazene
                System.out.println(niz_kod.get(k)+" "+niz_home.get(k)+" "+niz_away.get(k)+" "+niz_gh.get(k)+" "+niz_ga.get(k));     //ispis u konzolu
                String str = niz_kod.get(k).substring(6);
                int god = Integer.parseInt(str)+2000;         //godina(sezona) igranja utakmice
                l1[k].setText(god+":  "+niz_home.get(k)+"  "+niz_gh.get(k)+"-"+niz_ga.get(k)+"  "+niz_away.get(k));     //ispis na panel
                int gh = niz_gh.get(k);
                int ga = niz_ga.get(k);
                
                
                int golHpoluvreme =  niz_goloviHpoluvreme.get(k);
                int golApoluvreme =  niz_goloviApoluvreme.get(k);
                int sutH = niz_suteviH.get(k);
                int sutA = niz_suteviA.get(k);
                int sutokvirH = niz_suteviOkvirH.get(k);
                int sutokvirA = niz_suteviOkvirA.get(k);
                int faulH = niz_faulH.get(k);
                int faulA = niz_faulA.get(k);
                int kornerH = niz_korneH.get(k);
                int kornerA = niz_korneA.get(k);
                int zutiH = niz_zutiH.get(k);
                int zutiA = niz_zutiA.get(k);
                int crveniH = niz_crveniH.get(k);
                int crveniA = niz_crveniA.get(k);
                String sudija = niz_sudije.get(k);
                double kvotaH = niz_kvoteH.get(k);
                double kvotaX = niz_kvoteX.get(k);
                double kvotaA = niz_kvoteA.get(k);
               
                
                double b1 = (gh/9.0)*20 - 10;
                double b2 = (ga/7.0)*20 - 10;
                double b31 = 0.5*((golHpoluvreme/5.0)*20 - 10);
                double b32 = 0.5*((golApoluvreme/5.0)*20 - 10);
                double b4 = ((sutH-1)/42.0)*20 - 10;
                double b5 = (sutA/30.0)*20 - 10;
                double b6 = (sutokvirH/24.0)*20 - 10;
                double b7 = (sutokvirA/20.0)*20 - 10;
                double b81 = 0.125*(((faulH-1)/32.0)*20 - 10);
                double b82 = 0.125*(((faulA-1)/25.0)*20 - 10);
                double b83 = 0.125*((kornerH/20.0)*20 - 10);
                double b84 = 0.125*(((kornerA-0)/19.0)*20 - 10);
                double b85 = 0.125*(((zutiH-0)/7.0)*20 - 10);
                double b86 = 0.125*((zutiA/9.0)*20 - 10);
                double b87 = 0.125*(((crveniH-0)/2.0)*20 - 10);
                double b88 = 0.125*(((crveniA-0)/2.0)*20 - 10);
                double b9 = ((20/(17-1.09))*(kvotaH - 17) + 10)*(-1);
                double b10 = ((20/(29-1.16))*(kvotaA - 29) + 10)*(-1);
                double b3 = (b31+b32)/2.0;                
                double b8 = (b81+b82+b83+b84+b85+b86+b87+b88)/8.0;

                
                //racunanje
                if(niz_home.get(k).equals(domacin))
                {
                  sum += ((b1+b2+b3+b4+b5+b6+b7+b8+b9+b10)/10.0);
                  sum += (Math.abs(sum+3)*(1-(2016-god)*0.06));
                    Random r = new Random();
                    sum += r.nextDouble()%(0.1);         //random faktor(vrlo mali)
                }
                else
                {
                    sum += (b1+b2+b3+b4+b5+b6+b7+b8+b9+b10)/10.0;      
                    sum += Math.abs(sum+3)*(1-(2016-god)*0.06);
                    Random r = new Random();
                    sum -= r.nextDouble()%(0.1);     //random faktor(vrlo mali)
                }
        
            }
            mr = sum/j;
            System.out.println("MR je " +mr);
                    
           if(j == 0) empty_query = true;       //prazan upit?
           
           
           //TO DO : ovde treba da uradim algoritam u zavisnosti od selekcije radio buttona
           
           
           int rez1 = 0;    //ovo treba da pretvorim u procente (podelimo 100 sa zbirom da dobijemo 1 deo i onda mnozimo deo sa ovim vrednostima za procente)
           int rezX = 0;
           int rez2 = 0;
           double procenat1=0,procenatX=0,procenat2=0;
           
           if(jRadioButtonMenuItem3.isSelected())
           {
               //ALGORITAM LAGRANZ
               LagrangeInterpolation LI = new LagrangeInterpolation();      //algoritam je u drugoj klasi implementiran
               double polinom1[] = new double[niz_MR.size()];               //polinom za pobedu domacina
               double polinomX[] = new double[niz_MR.size()];               //polinom za neresen ishod
               double polinom2[] = new double[niz_MR.size()];               //polinom za pobedu gosta
               double y[] = new double[niz_MR.size()];                      //y koje cemo poslati u algoritam
               
               for(int i = 0; i < niz_MRHW.size(); i++) y[i] = (double)niz_MRHW.get(i);         //uzimamo vrednosti y iz lista    
               polinom1 = LI.findPolynomialFactors(x, y);                   //nalazimo polinom
               double s1 = 0;                                               //vrednost polinoma u tacki MR koju smo sracunali ce biti ovde
               int j1 = polinom1.length-1;                                  //stepen polinoma-1
               for(int i = 0; i < polinom1.length; i++)
               {
                    s1 += polinom1[i]*pow(mr,j1--);                     //ubacujem x za polinom (polyval simuliram ovim)
                    
               }
               rez1 = (int)s1;      //zaokruzim na int aproksimiranu vrednost
               
               for(int i = 0; i < niz_MRX.size(); i++) y[i] = (double)niz_MRX.get(i);   //ista stvar jos dva puta za nereseno i pobedu gosta
               polinomX = LI.findPolynomialFactors(x, y);
               s1 = 0;
               j1 = polinomX.length-1;
               for(int i = 0; i < polinomX.length; i++)
               {
                    s1 += polinomX[i]*pow(mr,j1--);
               }
               rezX = (int)s1;
               
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);
               polinom2 = LI.findPolynomialFactors(x, y);
               s1 = 0;
               j1 = polinom2.length-1;
               for(int i = 0; i < polinom2.length; i++)
               {
                    s1 += polinom2[i]*pow(mr,j1--);
               }
               rez2 = (int)s1;
                 System.out.println("aaaaaaaa "+rez1+"    "+rezX+"    "+rez2);
               int suma = Math.abs(rez1)+Math.abs(rez2)+Math.abs(rezX);                  //objasnjeno u komentarima gore
               double deo = (double)(100/(double)suma);
               procenat1 = deo*Math.abs(rez1);
               procenatX = deo*Math.abs(rezX);
               procenat2 = deo*Math.abs(rez2);
               
               

           }
           else if(jRadioButtonMenuItem4.isSelected())
           {
               //ALGORITAM REGRESIJA
               Regression r = new Regression();

               double polinom1[] = new double[niz_MR.size()];               //polinom za pobedu domacina
               double polinomX[] = new double[niz_MR.size()];               //polinom za neresen ishod
               double polinom2[] = new double[niz_MR.size()];               //polinom za pobedu gosta
               double y[] = new double[niz_MR.size()];                      //y koje cemo poslati u algoritam
               
                         
               for(int i = 0; i < niz_MRHW.size(); i++) y[i] = (double)niz_MRHW.get(i);         //uzimamo vrednosti y iz lista    
               polinom1 = r.regresijaPolinom(x, y, stepen);                   //nalazimo polinom
               double s1 = 0;                                               //vrednost polinoma u tacki MR koju smo sracunali ce biti ovde
               int j1 = 0;                                  //stepen polinoma-1
               for(int i = polinom1.length-1; i >= 0 ; --i)
               {
                    s1 += polinom1[j1]*pow(mr,j1++);                     //ubacujem x za polinom (polyval simuliram ovim)
               }
               rez1 = (int)s1;      //zaokruzim na int aproksimiranu vrednost
               
               for(int i = 0; i < niz_MRX.size(); i++) y[i] = (double)niz_MRX.get(i);   //ista stvar jos dva puta za nereseno i pobedu gosta
               polinomX = r.regresijaPolinom(x, y, stepen);  
               s1 = 0;
               j1 = 0;
               for(int i = polinomX.length-1; i >= 0 ; --i)
               {
                    s1 += polinomX[j1]*pow(mr,j1++);
               }
               rezX = (int)s1;
               
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);
               polinom2 = r.regresijaPolinom(x, y, stepen);  
               s1 = 0;
               j1 = 0;
               for(int i =  polinom2.length-1; i >= 0; --i)
               {
                    s1 += polinom2[j1]*pow(mr,j1++);
               }
               rez2 = (int)s1;
               System.out.println("aaaaaaaa "+rez1+"    "+rezX+"    "+rez2);
               int suma = Math.abs(rez1)+Math.abs(rez2)+Math.abs(rezX);                  //objasnjeno u komentarima gore
               double deo = (double)(100/(double)suma);
               procenat1 = deo*Math.abs(rez1);
               procenatX = deo*Math.abs(rezX);
               procenat2 = deo*Math.abs(rez2);

           }
           else if(jRadioButtonMenuItem5.isSelected())
           {
               // TO DO : regresija najblizih suseda
               NearestNeighbourRegression kNN = new NearestNeighbourRegression(koef);
               double y[] = new double[niz_MR.size()];                      //y koje cemo poslati u algoritam
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRHW.get(i);
               
               rez1 = (int)kNN.getResult(x, y, mr);
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRX.get(i);
               
               rezX = (int)kNN.getResult(x, y, mr);
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);
               
               rez2 = (int)kNN.getResult(x, y, mr);
               
               //System.out.println("aaaaaaaa "+rez1+"    "+rezX+"    "+rez2);
               int suma = Math.abs(rez1)+Math.abs(rez2)+Math.abs(rezX);                  //objasnjeno u komentarima gore
               double deo = (double)(100/(double)suma);
               procenat1 = deo*Math.abs(rez1);
               procenatX = deo*Math.abs(rezX);
               procenat2 = deo*Math.abs(rez2);
               
           }
           else if(jRadioButtonMenuItem6.isSelected())
           {
               //TREE DEC
               TreeDecision tr = new TreeDecision(niz_kod,niz_gh,niz_ga,niz_home,niz_away,niz_goloviHpoluvreme,niz_goloviApoluvreme,niz_suteviH,niz_suteviA,niz_suteviOkvirH,
               niz_suteviOkvirA,niz_korneH,niz_korneA,niz_zutiH,niz_zutiA,niz_crveniH,niz_crveniA,niz_faulH,niz_faulA,niz_kvoteH,niz_kvoteX,niz_kvoteA,niz_sudije);
               short rez = tr.racunaj(domacin, gost);
               if(rez == 1)
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                   jTextArea1.setBackground(Color.red);
                jTextArea2.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                   return;
               }
               else if(rez == 2)
               {
                   jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                        jTextArea3.setBackground(Color.red);
                                        jTextArea2.setBackground(new Color(51,255,0));
                jTextArea1.setBackground(new Color(51,255,0));
                        return;
               }
               else
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                       jTextArea2.setBackground(Color.red);
                                       jTextArea1.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                       return;
               }
               //System.out.println("Pobeda "+ rez);
           }
           else if(jRadioButtonMenuItem8.isSelected())
           {
               //neuronska
                     /* String trainingSetFileName = "PremierLeagueResults.txt";
                        int inputsCount = 8;
                         int outputsCount = 3;
                                 // create training set
                DataSet trainingSet = null;
                try {
                    trainingSet = TrainingSetImport.importFromFile(trainingSetFileName, inputsCount, outputsCount, ",");
                } catch (FileNotFoundException ex) {
                    System.out.println("File not found!");
                } catch (IOException | NumberFormatException ex) {
                    System.out.println("Error reading file or bad number format!");
                }
                
                                // create multi layer perceptron
                 System.out.println("Creating neural network");
                 MultiLayerPerceptron neuralNet = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 8, 30, 3);

                 // set learning parametars
                 MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();
                 learningRule.setLearningRate(0.3);
                 learningRule.setMomentum(0.7);

                 // learn the training set
                 System.out.println("Training neural network...");
                 neuralNet.learn(trainingSet);
                 System.out.println("Done!");*/
               
               /* Scanner fileIn22 = null;
		try {
			fileIn22 = new Scanner(new File("izlazNeuronskaTrening.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                ArrayList<ArrayList<Double>> ulazniPodaci = new ArrayList<ArrayList<Double>>();
                ArrayList<ArrayList<Double>> ilazPodaci1 = new ArrayList<ArrayList<Double>>();
                ArrayList<ArrayList<Double>> ilazPodaci2 = new ArrayList<ArrayList<Double>>();
		int i5 = 0;
                while(fileIn22.hasNext())
		{
                    
			String line = fileIn22.nextLine();
			//String pom[] = line.split(":");
                        String pom2[] = line.split(",");
                        //if(pom2[0].equals(domacin))
                        //{
                        ArrayList<Double> temp = new ArrayList<Double>();
                        
                            double golmanH = Double.parseDouble(pom2[0]);
                            double odbranaH = Double.parseDouble(pom2[1]);
                            double sredinaH = Double.parseDouble(pom2[2]);
                            double napadH = Double.parseDouble(pom2[3]);
                            
                            
                            
                        //}
                        
//                        if(pom[0].equals(gost))
  //                      {ovo golman drugog tima?, ma da, to je ta osmorka
                            double golmanH2 = Double.parseDouble(pom2[4]);
                            double odbranaH2 = Double.parseDouble(pom2[5]);
                            double sredinaH2 = Double.parseDouble(pom2[6]);
                            double napadH2 = Double.parseDouble(pom2[7]);
                            temp.add(golmanH);
                            temp.add(odbranaH);
                            temp.add(sredinaH);
                            temp.add(napadH);
                            temp.add(golmanH2);
                            temp.add(odbranaH2);
                            temp.add(sredinaH2);
                            temp.add(napadH2);
                            ulazniPodaci.add(temp);
                            //cek da skontam sta je taj niz :D
                           double prvi = Double.parseDouble(pom2[8]);
                           double prvi1 = Double.parseDouble(pom2[9]);
                           double prvi2 = Double.parseDouble(pom2[10]);
                           
                           ArrayList<Double> evo_ti_pom = new ArrayList<Double>();
                            ArrayList<Double> evo_ti_pom1 = new ArrayList<Double>();
                           if(prvi==1.0) evo_ti_pom.add(1.00);//ovo samo konvetuje tvoja 3 bita u 1 za prvu mrezu
                           if(prvi1==1.0) evo_ti_pom.add(0.00);
                           if(prvi2==1.0) evo_ti_pom.add(0.00);
                            
                           if(prvi==1.0) evo_ti_pom1.add(0.00);//isto za drugu
                           if(prvi1==1.0) evo_ti_pom1.add(0.00);
                           if(prvi2==1.0) evo_ti_pom1.add(1.00);//
                            ilazPodaci1.add(evo_ti_pom);
                           ilazPodaci2.add(evo_ti_pom1);
                        
                         
                }
                fileIn22.close();*/

                 //ArrayList<Double> nizTest = new ArrayList<Double>();
                 double[] nizTest = new double[8];
                 //nizTest[10] = 0.0; nizTest[8] = 0.0; nizTest[9] = 0;
                Scanner fileIn2 = null;
		try {
			fileIn2 = new Scanner(new File("timoviRating17.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn2.hasNext())
		{
			String line = fileIn2.nextLine();
			String pom[] = line.split(":");
                        String pom2[] = pom[1].split(",");
                        if(pom[0].equals(domacin))
                        {
                            double golmanH = Double.parseDouble(pom2[0]);
                            double odbranaH = Double.parseDouble(pom2[1]);
                            double sredinaH = Double.parseDouble(pom2[2]);
                            double napadH = Double.parseDouble(pom2[3]);
                            
                            nizTest[0] = golmanH; nizTest[1] = odbranaH; nizTest[2] = sredinaH; nizTest[3] = napadH;
                            /*nizTest.add(golmanH);
                            nizTest.add(odbranaH);
                            nizTest.add(sredinaH);
                            nizTest.add(napadH);*/
                            
                        }
                        
                        if(pom[0].equals(gost))
                        {
                            double golmanH = Double.parseDouble(pom2[0]);
                            double odbranaH = Double.parseDouble(pom2[1]);
                            double sredinaH = Double.parseDouble(pom2[2]);
                            double napadH = Double.parseDouble(pom2[3]);
                            nizTest[4] = golmanH; nizTest[5] = odbranaH; nizTest[6] = sredinaH; nizTest[7] = napadH;
                            /*nizTest.add(golmanH);
                            nizTest.add(odbranaH);
                            nizTest.add(sredinaH);
                            nizTest.add(napadH);*/
                        }
                }
                fileIn2.close();
               
            /*NeuralNetwork network1 = new NeuralNetwork();
            network1.Add(new NeuralLayer(8, 10, "sigmoid"));
            network1.Add(new NeuralLayer(10, 10, "sigmoid"));
            network1.Add(new NeuralLayer(10, 14, "sigmoid"));
            network1.Add(new NeuralLayer(14, 12, "sigmoid"));
            network1.Add(new NeuralLayer(12, 10, "sigmoid"));
             network1.Add(new NeuralLayer(10, 14, "sigmoid"));
            network1.Add(new NeuralLayer(14, 12, "sigmoid"));
            network1.Add(new NeuralLayer(12, 10, "sigmoid"));
            network1.Add(new NeuralLayer(10, 8, "sigmoid"));
            network1.Add(new NeuralLayer(8, 4, "sigmoid"));
            network1.Add(new NeuralLayer(4, 1, "sigmoid"));

            NeuralNetwork network2 = new NeuralNetwork();
            network2.Add(new NeuralLayer(8, 10, "sigmoid"));
            network2.Add(new NeuralLayer(10, 10, "sigmoid"));
            network2.Add(new NeuralLayer(10, 14, "sigmoid"));
            network2.Add(new NeuralLayer(14, 12, "sigmoid"));
            network2.Add(new NeuralLayer(12, 10, "sigmoid"));
             network2.Add(new NeuralLayer(10, 14, "sigmoid"));
            network2.Add(new NeuralLayer(14, 12, "sigmoid"));
            network2.Add(new NeuralLayer(12, 10, "sigmoid"));
            network2.Add(new NeuralLayer(10, 8, "sigmoid"));
            network2.Add(new NeuralLayer(8, 4, "sigmoid"));
            network2.Add(new NeuralLayer(4, 1, "sigmoid"));*/
            //jel to neka n-torka? da  za koju mi treba izlaz, a trening,prciaj :D
                NeuralNetwork neuralNet =  MultiLayerPerceptron.load("neuronska1");
                //neuralNet.save("neuronska1");
                neuralNet.setInput(nizTest);
                neuralNet.calculate();
                double[] networkOutput = neuralNet.getOutput();
                //System.out.println("aaaa "+networkOutput);
                //System.out.println("uzlaz " + ulazniPodaci.size());
                //System.out.println("uzlaz1 " + ulazniPodaci.get(0).size());
                //System.out.println("uzlaz2 " + ilazPodaci2.size());
               /* network1.fit(ulazniPodaci, ilazPodaci1, 0.3, 0.7, 100);
                network2.fit(ulazniPodaci, ilazPodaci2, 0.3, 0.7, 100);
                
                double[] networkOutput = new double[3];
                ArrayList<Double> rez11=network1.predict(nizTest);
                System.out.println("prvi reeeeeeeez   "+rez11);
                ArrayList<Double> rez21=network1.predict(nizTest);
                         System.out.println("drugi reeeeeeeez   "+rez11);//ovde kontam da je negde , tako?da da, rez1 i rez2 su rezultati obe mreze, pa sam ja dole popunio network output kao da si koristio frameforwk da anhea bi ti menjao ostatak koda
                double ozbrez1 = rez11.get(0);//rez11 je lista, pa uzmemo prvi (i jedini) izlaz:)
                double ozbrez2 = rez21.get(0);
                
                if(ozbrez1 > 0.6)//znaci prvi je
                {
                    networkOutput[0]=1;
                    networkOutput[1]=0;
                    networkOutput[2]=0;
                }
                else if(ozbrez1 <  0.4) 
                {
                    networkOutput[0]=0;
                    networkOutput[1]=0;
                    networkOutput[2]=1;
                }
                else 
                {
                    networkOutput[0]=0;
                    networkOutput[1]=1;
                    networkOutput[2]=0;
                }*/
                

               if(networkOutput[0] > networkOutput[1] && networkOutput[0] > networkOutput[2])
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                   jTextArea1.setBackground(Color.red);
                jTextArea2.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                   return;
               }
               else if(networkOutput[2] > networkOutput[1] && networkOutput[2] > networkOutput[0])
               {
                   jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                        jTextArea3.setBackground(Color.red);
                                        jTextArea2.setBackground(new Color(51,255,0));
                jTextArea1.setBackground(new Color(51,255,0));
                        return;
               }
               else
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                       jTextArea2.setBackground(Color.red);
                                       jTextArea1.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                       return;
               }
           }
           else
           {
               //RADNOM FOREST
               RandomForrest rf = new RandomForrest(niz_kod,niz_gh,niz_ga,niz_home,niz_away,niz_goloviHpoluvreme,niz_goloviApoluvreme,niz_suteviH,niz_suteviA,niz_suteviOkvirH,
               niz_suteviOkvirA,niz_korneH,niz_korneA,niz_zutiH,niz_zutiA,niz_crveniH,niz_crveniA,niz_faulH,niz_faulA,niz_kvoteH,niz_kvoteX,niz_kvoteA,niz_sudije);
               int rez = rf.result(domacin, gost, 7);
               if(rez == 1)
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                   jTextArea1.setBackground(Color.red);
                jTextArea2.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                   return;
               }
               else if(rez == 2)
               {
                   jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                        jTextArea3.setBackground(Color.red);
                                        jTextArea2.setBackground(new Color(51,255,0));
                jTextArea1.setBackground(new Color(51,255,0));
                        return;
               }
               else
               {
                                      jTextArea1.setText("");
                   jTextArea2.setText("");
                   jTextArea3.setText("");
                       jTextArea2.setBackground(Color.red);
                                       jTextArea1.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                       return;
               }
           }
           
           if(procenat1 > 11 && procenatX > 3 && procenat2 > 4)
           {
               //korektivni faktori za ekipe sa vecom reputacijom i dugom tradicijom u BPL
               if(domacin.equals("Arsenal") || domacin.equals("Chelsea") || domacin.equals("Man United") 
                       || domacin.equals("Man City") || domacin.equals("Liverpool") || domacin.equals("Tottenham"))
               {
                    if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                        || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                    {
                        procenatX += 6;
                        procenat1 -= 2;
                        procenat2 -= 4;
                    }
                    else
                    {
                        procenat1 += 7;
                        procenat2 -= 4;
                        procenatX -= 3;
                    }
               }
               
               else if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                        || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
               {
                        procenat2 += 10;
                        procenat1 -= 11;
                        procenatX += 1;              
               }           
           }
           
           /*
                OVDE TREBA DA UPISEM U POLJA REZULTATE I POCISTIM SVE NIZOVE
           */
            if(!empty_query)
            {
                jTextArea1.setText("                    "+Double.toString(Math.round(procenat1*100.0)/100.0)+" %");
                jTextArea2.setText("                    "+Double.toString(Math.round(procenatX*100.0)/100.0)+" %");
                jTextArea3.setText("                    "+Double.toString(Math.round(procenat2*100.0)/100.0)+" %");
                jTextArea1.setBackground(new Color(51,255,0));
                jTextArea2.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
                niz_kod.clear();
                niz_home.clear();
                niz_away.clear();
                niz_gh.clear();
                niz_ga.clear();
                niz_goloviHpoluvreme.clear();
                niz_goloviApoluvreme.clear();
                niz_suteviH.clear();
                niz_suteviA.clear();
                niz_suteviOkvirH.clear();
                niz_suteviOkvirA.clear();
                niz_korneH.clear();
                niz_korneA.clear();
                niz_zutiH.clear();
                  niz_zutiA.clear();
                  niz_crveniH.clear();
                niz_crveniA.clear();
                niz_sudije.clear();
                niz_kvoteH.clear();
                niz_kvoteX.clear();
                niz_kvoteA.clear();
                niz_faulH.clear();
                niz_faulA.clear();
            }
            else        //nisu igrali 
            {
                JOptionPane.showMessageDialog(null, l.getNisu_igrali2_default(), l.getNisu_igrali1_default(), JOptionPane.INFORMATION_MESSAGE);
                resetPanel();
            }


        }
        
    }    
    
    //radio buttoni da ne budu selektovani u isto vreme
    public void AddInGroup()
    {
        ButtonGroup group = new ButtonGroup();
        group.add(jRadioButtonMenuItem1);
        group.add(jRadioButtonMenuItem2);
    }
    
    public void AddInGroup1()
    {
        ButtonGroup group = new ButtonGroup();
        group.add(jRadioButtonMenuItem3);
        group.add(jRadioButtonMenuItem4);
        group.add(jRadioButtonMenuItem5);
        group.add(jRadioButtonMenuItem6);
        group.add(jRadioButtonMenuItem7);
        group.add(jRadioButtonMenuItem8);
    }
    
    /*Calculate button*/
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        resetPanel();
        Calculate();
    }//GEN-LAST:event_jButton1ActionPerformed
    
    /*Exit*/
    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
                // TODO add your handling code here:
                System.exit(0);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    /*1. combo box*/
    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
            // TODO add your handling code here:
            if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED)
            {
                Object item = evt.getItem();
                if(item.toString() == "Bournemouth") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1bournemouth.png")));
                else if(item.toString() == "Arsenal") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png")));
                else if(item.toString() == "Burnley") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_burnley.png")));
                else if(item.toString() == "Chelsea") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_chelsea.png")));
                else if(item.toString() == "Crystal Palace") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_crystal.png")));
                else if(item.toString() == "Everton") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_everton.png")));
                else if(item.toString() == "Hull") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_hull-city.png")));
                else if(item.toString() == "Leicester") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_leicester-city.png")));
                else if(item.toString() == "Liverpool") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_liverpool.png")));
                else if(item.toString() == "Man City") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_manchester-city.png")));
                else if(item.toString() == "Man United") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_manchester-united.png")));
                else if(item.toString() == "Middlesbrough") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_middlesbrough.png")));
                else if(item.toString() == "Southampton") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_southampton.png")));
                else if(item.toString() == "Stoke") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_stoke.png")));
                else if(item.toString() == "Sunderland") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_sunderland.png")));
                else if(item.toString() == "Swansea") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_swansea.png")));
                else if(item.toString() == "Tottenham") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_tottenham.png")));
                else if(item.toString() == "Watford") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_watford.png")));
                else if(item.toString() == "West Brom") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_wba.png")));
                else if(item.toString() == "West Ham") jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_west_ham_united.png")));
            }
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    /*2. combo box*/
    private void jComboBox2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox2ItemStateChanged
            // TODO add your handling code here:
                        if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED)
            {
                Object item = evt.getItem();
                if(item.toString() == "Bournemouth") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1bournemouth.png")));
                else if(item.toString() == "Arsenal") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png")));
                else if(item.toString() == "Burnley") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_burnley.png")));
                else if(item.toString() == "Chelsea") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_chelsea.png")));
                else if(item.toString() == "Crystal Palace") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_crystal.png")));
                else if(item.toString() == "Everton") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_everton.png")));
                else if(item.toString() == "Hull") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_hull-city.png")));
                else if(item.toString() == "Leicester") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_leicester-city.png")));
                else if(item.toString() == "Liverpool") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_liverpool.png")));
                else if(item.toString() == "Man City") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_manchester-city.png")));
                else if(item.toString() == "Man United") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_manchester-united.png")));
                else if(item.toString() == "Middlesbrough") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_middlesbrough.png")));
                else if(item.toString() == "Southampton") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_southampton.png")));
                else if(item.toString() == "Stoke") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_stoke.png")));
                else if(item.toString() == "Sunderland") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_sunderland.png")));
                else if(item.toString() == "Swansea") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_swansea.png")));
                else if(item.toString() == "Tottenham") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_tottenham.png")));
                else if(item.toString() == "Watford") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_watford.png")));
                else if(item.toString() == "West Brom") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_wba.png")));
                else if(item.toString() == "West Ham") jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_west_ham_united.png")));
            }
    }//GEN-LAST:event_jComboBox2ItemStateChanged

    
    /*nepotrebno*/
    private void jMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu1ActionPerformed
        // TODO add your handling code here:

       
    }//GEN-LAST:event_jMenu1ActionPerformed
    
    /*reset*/
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        jComboBox1.setSelectedItem("Arsenal");
        jComboBox2.setSelectedItem("Arsenal");
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png")));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rsz_1arsenal.png")));
         resetPanel();
                jTextArea1.setText("");
                jTextArea2.setText("");
                jTextArea3.setText("");
               jTextArea1.setBackground(new Color(51,255,0));
                jTextArea2.setBackground(new Color(51,255,0));
                jTextArea3.setBackground(new Color(51,255,0));
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    /*creator*/
    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, l.getInfo_default1(), l.getPop_default1(), JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMenuItem6ActionPerformed
    
    /*about*/
    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, l.getInfo_default2(), l.getPop_default2(), JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    /*user manual*/
    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, l.getInfo_default3(), l.getPop_default3(), JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    /*Calculate from menu bar*/
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        Calculate();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    /*Srpski*/
    private void jRadioButtonMenuItem2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem2ItemStateChanged
        // TODO add your handling code here:
        if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED)
        {
            jLabel1.setText("Pobeda Domacina");
            jLabel2.setText("Nereseno");
            jLabel3.setText("Pobeda Gosta");
            jLabel6.setText("DOMACIN");
            jLabel7.setText("GOST");
            
            jButton1.setText("Izracunaj");
            
            jMenu1.setText("Opcije");
            jMenu3.setText("Jezik");
            jMenu4.setText("Pomoc");
            jMenu6.setText("Parametri");
            
            jMenuItem1.setText("Izracunaj");
            jMenuItem2.setText("Resetuj");
            jMenuItem3.setText("Izlaz");
            
            jMenuItem4.setText("Uputstvo za korisnike");
            jMenuItem5.setText("O aplikaciji");
            jMenuItem6.setText("Autor");
            jMenuItem8.setText("Statistika");

            jRadioButtonMenuItem1.setText("Engleski");
            jRadioButtonMenuItem2.setText("Srpski");
            jRadioButtonMenuItem5.setText("Regresija najblizih komsija");
            
            jMenuItem9.setText("Regresija (stepen)");
            jMenuItem10.setText("Regresija najblizih komsija (k)");
            
            jMenuItem11.setText("Najbolji stepen regresije");
            jMenuItem12.setText("Najbolje k regresije najblizih komsija");
            
            l.setPop_default1(l.getPop1SRB());  
            l.setPop_default2(l.getPop2SRB());
            l.setPop_default3(l.getPop3SRB());
            
            l.setSame_sides_default(l.getSame_sidesSRB());
            
            l.setInfo_default1(l.getInfoMessage1SRB());
            l.setInfo_default2(l.getInfoMessage2SRB());
            l.setInfo_default3(l.getInfoMessage3SRB());
            
            l.setNisu_igrali1_default(l.getNisu_igrali1SRB());
            l.setNisu_igrali2_default(l.getNisu_igrali2SRB());
            
            l.setBad_c(l.getBad_c_SRB());
            
            l.setLaG_default(l.getLaG_SRB());
            l.setReg_default(l.getReg_SRB());
            
            
            jMenu5.setText(l.getMet_SRB());
            
            jRadioButtonMenuItem3.setText(l.getLaG_SRB());
            jRadioButtonMenuItem4.setText(l.getReg_SRB());
        }
    }//GEN-LAST:event_jRadioButtonMenuItem2ItemStateChanged

    /*Engleski*/
    private void jRadioButtonMenuItem1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem1ItemStateChanged
        // TODO add your handling code here:
        if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED)
        {
            jLabel1.setText("HOME WIN");
            jLabel2.setText("DRAW");
            jLabel3.setText("AWAY WIN");
            jLabel6.setText("HOME");
            jLabel7.setText("AWAY");
            
            jButton1.setText("Calculate");
            
            jMenu1.setText("Options");
            jMenu3.setText("Language");
            jMenu4.setText("Help");
            jMenu6.setText("Parametars");
            
            jMenuItem1.setText("Calculate");
            jMenuItem2.setText("Reset");
            jMenuItem3.setText("Exit");
            
            jMenuItem4.setText("User manual");
            jMenuItem5.setText("About");
            jMenuItem6.setText("Creator");
            jMenuItem8.setText("Statistic");

            jRadioButtonMenuItem1.setText("English");
            jRadioButtonMenuItem2.setText("Serbian");
            jRadioButtonMenuItem5.setText("Nearest Neighbour Regression");
            
            jMenuItem9.setText("Regression (degree)");
            jMenuItem10.setText("NN Regression (k)");
            
            jMenuItem11.setText("The best degree");
            jMenuItem12.setText("The best k");
            
            jMenu5.setText(l.getMet_EN());
            
            jRadioButtonMenuItem3.setText(l.getLaG_EN());
            jRadioButtonMenuItem4.setText(l.getReg_EN());

            l.setLaG_default(l.getLaG_EN());
            l.setReg_default(l.getReg_EN());
            
            l.setPop_default1(l.getPop1EN());  
            l.setPop_default2(l.getPop2EN());
            l.setPop_default3(l.getPop3EN());
            
            l.setSame_sides_default(l.getSame_sidesEN());
            
            l.setInfo_default1(l.getInfoMessage1EN());
            l.setInfo_default2(l.getInfoMessage2EN());
            l.setInfo_default3(l.getInfoMessage3EN());
            
            l.setNisu_igrali1_default(l.getNisu_igrali1EN());
            l.setNisu_igrali2_default(l.getNisu_igrali2EN());
            
        }
    }//GEN-LAST:event_jRadioButtonMenuItem1ItemStateChanged

    private void jRadioButtonMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonMenuItem3ActionPerformed

    /*Statistika*/
    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
        Statistics s = new Statistics(niz_MR, niz_MRHW,niz_MRX,niz_MRAW,stepen,koef);
        
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    //visak
    private void jRadioButtonMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonMenuItem5ActionPerformed
   
    /*Stepen regresije unos*/
    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        // TODO add your handling code here:
        String odg;
        odg = JOptionPane.showInputDialog("n = ");
        try{
            
            stepen = Integer.parseInt(odg);
            if (stepen > 100 || stepen < 1) throw new Exception();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Bad input!", l.getNisu_igrali1_default(),  JOptionPane.ERROR_MESSAGE);
            stepen = 2;
        }
    }//GEN-LAST:event_jMenuItem9ActionPerformed
    
    /*NN regresija unos K*/
    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
        String odg;
        odg = JOptionPane.showInputDialog("k = ");
        try{
            
            koef = Integer.parseInt(odg);
            if (koef > 65 || koef < 1) throw new Exception();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Bad input!",l.getNisu_igrali1_default(),  JOptionPane.ERROR_MESSAGE);
            koef = 27;
        }
    }//GEN-LAST:event_jMenuItem10ActionPerformed
    
    /*racunamo najbolji stepen za regresiju*/
    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        // TODO add your handling code here:
        //BestDegree bd = new BestDegree();
        int max = -1;
        double maxP = 0;
        for(int i = 1; i < 100; i++)
        {
            Statistics s = new Statistics(niz_MR, niz_MRHW,niz_MRX,niz_MRAW,i,koef);
            s.setVisible(false);

            double[] r16 = s.getRez2();
 
            
            /*double procenat2 = (double)(r16[1])/(double)(s.getBrojUtakmica())*100.0;
            procenat2 = Math.round(procenat2*100.0)/100.0;
            */
            System.out.println(i+"   "+r16[1]);
            
            if(r16[1] > maxP) { maxP = r16[1]; max = i;}
        }
        
        System.out.println("Max = "+max+"     "+maxP);
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    /*racunamo najbolje k za nnreg*/
    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        // TODO add your handling code here:
         /*BestK bk = new BestK(niz_MRHW,niz_MRX,niz_MRAW,x);
        double max[];

        max = bk.najboljeK();  

        JOptionPane.showMessageDialog(new JPanel(), "k = "+max[0]+"     "+max[1]+"  %");*/
                 //BestDegree bd = new BestDegree();
        int max = -1;
        double maxP = 0;
        for(int i = 1; i < 65; i++)
        {
            Statistics s = new Statistics(niz_MR, niz_MRHW,niz_MRX,niz_MRAW,stepen,i);
            s.setVisible(false);

            double[] r16 = s.getRez2();
 
            
            /*double procenat2 = (double)(r16[1])/(double)(s.getBrojUtakmica())*100.0;
            procenat2 = Math.round(procenat2*100.0)/100.0;
            */
            System.out.println(i+"   "+r16[2]);
            
            if(r16[2] > maxP) { maxP = r16[2]; max = i;}
        }
        
        System.out.println("Max = "+max+"     "+maxP);
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jRadioButtonMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButtonMenuItem7ActionPerformed
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
 
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                    new MyFrame().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    public javax.swing.JComboBox<String> jComboBox1;
    public javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel4;
    public javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem3;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem4;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem5;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem6;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem7;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    public javax.swing.JTextArea jTextArea1;
    public javax.swing.JTextArea jTextArea2;
    public javax.swing.JTextArea jTextArea3;
    // End of variables declaration//GEN-END:variables
}
