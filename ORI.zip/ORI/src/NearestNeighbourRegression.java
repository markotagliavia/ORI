/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tijana-PC
 */
public class NearestNeighbourRegression {
    
    private int koef;
    
    public NearestNeighbourRegression(int koef)
    {
        this.koef = koef;
    }
    
    public double getResult(double x[], double y[], double mr)
    {
        double result = -1;
        double rez[][] = new double[y.length][2];
        double suma = 0;
        double temp,temp1;
        
        for(int i = 0; i < x.length; ++i)
        {
            rez[i][0] = Math.abs(x[i]-mr);
            rez[i][1] = y[i];
        }
       
        for(int i = 0; i < (x.length-1); ++i)
        {
            for(int j = 0; j < (x.length - i - 1); ++j)
            {
                if(rez[j][0] > rez[j+1][0])
                {
                    temp = rez[j][0];
                    temp1 = rez[j][1];
                    rez[j][0] =  rez[j+1][0];
                    rez[j][1] =  rez[j+1][1];
                    rez[j+1][0] = temp;
                    rez[j+1][1] = temp1;
                }
            
            
            }      
        }
        for(int i = 0; i < koef; ++i)
        {
            suma += rez[i][1];
        }

        result = suma/(double)koef;
        
        return result;
    }
}
