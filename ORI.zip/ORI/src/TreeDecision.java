
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tijana-PC
 */
public class TreeDecision {
    
    private List<String> niz_kod;       
    private List<Integer> niz_gh; 
    private List<Integer> niz_ga;        //lista datih golova gosta
    private List<String> niz_home;        //lista imena domacina
    private List<String> niz_away;        //lista imena gostiju
    private List<Integer> niz_goloviHpoluvreme;        //lista datih golova domacina
    private List<Integer> niz_goloviApoluvreme;        //lista datih golova gosta
    private List<Integer> niz_suteviH;        //lista imena domacina
    private List<Integer> niz_suteviA;        //lista imena gostiju
    private List<Integer> niz_suteviOkvirH;        //lista datih golova domacina
    private List<Integer> niz_suteviOkvirA;        //lista datih golova gosta
    private List<Integer>  niz_korneH;        //lista datih golova domacina
    private List<Integer> niz_korneA;        //lista datih golova gosta
    private List<Integer> niz_zutiH;        //lista datih golova domacina
    private List<Integer> niz_zutiA;        //lista datih golova gosta
    private List<Integer> niz_crveniH;        //lista datih golova domacina
    private List<Integer> niz_crveniA;        //lista datih golova gosta
    private List<Integer> niz_faulH;        //lista datih golova domacina
    private List<Integer> niz_faulA;        //lista datih golova gosta
    
    private List<Double> niz_kvoteH;
    private List<Double> niz_kvoteX;
    private List<Double> niz_kvoteA;
    
    private List<String> niz_sudije;

    TreeDecision(List<String> niz_kod, List<Integer> niz_gh, List<Integer> niz_ga, List<String> niz_home, List<String> niz_away, List<Integer> niz_goloviHpoluvreme, List<Integer> niz_goloviApoluvreme, List<Integer> niz_suteviH, List<Integer> niz_suteviA, List<Integer> niz_suteviOkvirH, List<Integer> niz_suteviOkvirA, List<Integer> niz_korneH, List<Integer> niz_korneA, List<Integer> niz_zutiH, List<Integer> niz_zutiA, List<Integer> niz_crveniH, List<Integer> niz_crveniA, List<Integer> niz_faulH, List<Integer> niz_faulA, List<Double> niz_kvoteH, List<Double> niz_kvoteX, List<Double> niz_kvoteA, List<String> niz_sudije) {
        this.niz_kod = niz_kod;
        this.niz_gh = niz_gh;
        this.niz_ga = niz_ga;
        this.niz_home = niz_home;
        this.niz_away = niz_away;
        this.niz_goloviHpoluvreme = niz_goloviHpoluvreme;
        this.niz_goloviApoluvreme = niz_goloviApoluvreme;
        this.niz_suteviH = niz_suteviH;
        this.niz_suteviA = niz_suteviA;
        this.niz_suteviOkvirH = niz_suteviOkvirH;
        this.niz_suteviOkvirA = niz_suteviOkvirA;
        this.niz_korneH = niz_korneH;
        this.niz_korneA = niz_korneA;
        this.niz_zutiH = niz_zutiH;
        this.niz_zutiA = niz_zutiA;
        this.niz_crveniH = niz_crveniH;
        this.niz_crveniA = niz_crveniA;
        this.niz_faulH = niz_faulH;
        this.niz_faulA = niz_faulA;
        this.niz_kvoteH = niz_kvoteH;
        this.niz_kvoteA = niz_kvoteA;
        this.niz_kvoteX = niz_kvoteX;
        this.niz_sudije = niz_sudije;
        
    }
    
    public short racunaj(String domaci, String gosti){
    
        //Vraca 0 za nereseno, pobednik domacin 1 pobednik gost2
        short rez = 0;
        int brojUtakmica = 0;
        List<Integer> utakmice = new ArrayList<Integer>();
       
        for(int i = 0; i < this.niz_home.size(); ++i)
        {
            
            if((niz_home.get(i).equals(domaci) && niz_away.get(i).equals(gosti))||(niz_home.get(i).equals(gosti) && niz_away.get(i).equals(domaci)))
            {
                ++brojUtakmica;
                utakmice.add(i);
            }
        }
    
        int brojac = 0;
        boolean t;
        
        
        t = najteziRomb(domaci, gosti, 1);
        if(t) {/*System.out.println("Najtezi");*/return 1;}
        t = najteziRomb(domaci, gosti, -1);
        if(t) {/*System.out.println("Najtezi");*/return 2;}
        
        t = kvota(domaci);
        if(t) {/*System.out.println("KVOTA");*/return 1;}
        
        t = kvota(gosti);
        if(t) {/*System.out.println("KVOTA");*/return 2;}
        
        
        
        t = dalVoleSudijaDomace();
        if(t) {/*System.out.println("SUDIJA");*/return 1;}
        
         
         t = goloviIKartoni(domaci, gosti, 1);
        if(t) {/*System.out.println("KARTONI");*/return 1;}
        t = goloviIKartoni(domaci, gosti, -1);
        if(t) {/*System.out.println("KARTONI");*/return 2;}
        
        
        t = rombDesno34(domaci, gosti, 1);
        if(t) {//System.out.println("desno3 predikcija 1");
                return 1;}
        t = rombDesno34(domaci, gosti, -1);
        if(t) {//System.out.println("desno4  predikcija 2");
                return 2;}
        
        
        
        
        
        
       //golovi kartoni
        
        
        
        
        
        
        
        
        
        short vrati = ishod(utakmice,domaci,gosti); 
        if(vrati != -1)
        {
            //System.out.println("ishod predikcija "+vrati);

            return vrati;
        }
        else
        {
        if(brojUtakmica >= 4)
        {
            
            //nema ni jednog izlaza, nastavljam algoritam provera da li je broj pobeda za nekog bila uvek veca od 50
                short vrati1 = utakmice4pobedik(utakmice,domaci,gosti);
                if(vrati1 != -1)
                {
                //System.out.println("cetvorke predikcija "+vrati1);
                
                    return vrati1;
                }
                
            
        }
        else
        {
            short rD1 = rombDesno1(domaci, gosti);
            if(rD1 == 1) {            
               // System.out.println("desno1 predikcija 1");
                return 1;}
            else if(rD1 == 2){
                //System.out.println("desno1 predikcija 2");
                return 2;}
            else
            {
                boolean t1 = rombDesno2();
                if(t1) {
                //System.out.println("desno2  predikcija 0");
                return 0;}
            }
        }
        }
        
        
        
        return 0;
    }
    
    public short rombDesno1(String domacin, String gost)
    {
       // System.out.println("Markov ispis odavde");
        //-1 ide dalje algoritam    1-predikcija na domace  2-predikcija na goste
        short brojacDomacin = 0;
        short brojacGost = 0;
        for(short i1 = 0; i1 < niz_kod.size(); i1++)
        {
            if(niz_home.get(i1).equals(domacin))
            {
                if(niz_gh.get(i1) > niz_ga.get(i1)) brojacDomacin++;
               // System.out.println(niz_home.get(i1)+" "+niz_away.get(i1)+" "+niz_gh.get(i1)+" "+niz_ga.get(i1));
            }
            else if(niz_away.get(i1).equals(domacin))
            {
                if(niz_ga.get(i1) > niz_gh.get(i1)) brojacDomacin++;
               // System.out.println(niz_home.get(i1)+" "+niz_away.get(i1)+" "+niz_gh.get(i1)+" "+niz_ga.get(i1));
            }
        }
        
        if(brojacDomacin == niz_kod.size()) return 1;
        else
        {
            for(short i1 = 0; i1 < niz_kod.size(); i1++)
            {
                if(niz_home.get(i1).equals(gost))
                {
                    if(niz_gh.get(i1) > niz_ga.get(i1)) brojacGost++;
                  //  System.out.println(niz_home.get(i1)+" "+niz_away.get(i1)+" "+niz_gh.get(i1)+" "+niz_ga.get(i1));
                }
                else if(niz_away.get(i1).equals(gost))
                {
                    if(niz_ga.get(i1) > niz_gh.get(i1)) brojacGost++;
                   // System.out.println(niz_home.get(i1)+" "+niz_away.get(i1)+" "+niz_gh.get(i1)+" "+niz_ga.get(i1));
                }
            }
            if(brojacGost == niz_kod.size()) return 2;
        }
        
        return -1;
    }
    
    public boolean rombDesno34(String domacin, String gost, int metoda)
    {
        //ako je metoda 1 onda je u pitanju romb 3 sa desne strane
        //ako je metoda -1 onda je u pitanju romb 4 sa desne strane
        boolean t1 = false;
        
        double goalT1 = 0;
        double goalT2 = 0;
        double sutT1 = 0;
        double sutT2 = 0;
        double sutOT1 = 0;
        double sutOT2 = 0;
        for(short i = 0; i<niz_kod.size(); i++)
        {
            if(niz_home.get(i).equals(domacin))
            {
                goalT1 += niz_gh.get(i);
                goalT2 += niz_ga.get(i);
                sutT1 += niz_suteviH.get(i);
                sutT2 += niz_suteviA.get(i);
                sutOT1 += niz_suteviOkvirH.get(i);
                sutOT2 += niz_suteviOkvirA.get(i);
            }
            else if(niz_away.get(i).equals(domacin))
            {
                goalT1 += niz_ga.get(i);
                goalT2 += niz_gh.get(i);
                sutT1 += niz_suteviA.get(i);
                sutT2 += niz_suteviH.get(i);
                sutOT1 += niz_suteviOkvirA.get(i);
                sutOT2 += niz_suteviOkvirH.get(i);
            }
        }
        double avgT1 = goalT1/ (niz_kod.size()*1.0);
        double avgT2 = goalT2/ (niz_kod.size()*1.0);
        double avgST1 = sutT1 / (niz_kod.size()*1.0);
        double avgST2 = sutT2 / (niz_kod.size()*1.0);
        double avgSOT1 = sutOT1 / (niz_kod.size()*1.0);
        double avgSOT2 = sutOT2 / (niz_kod.size()*1.0);
        
        
        if(metoda == 1)
        {
                if(avgT1 > avgT2 && avgST1 > avgST2 && avgSOT1 > avgSOT2)
                {
                    t1 = true;
                }
        }
        else
        {
                if(avgT1 < avgT2 && avgST1 < avgST2 && avgSOT1 < avgSOT2)
                {
                    t1 = true;
                }
        }
        
        return t1;
    }
    
    
   public boolean rombDesno2()
   {
             short i = 0; // broj neresenih
            for(short i1 = 0; i1 < niz_kod.size(); i1++)
            {
                if(niz_gh.get(i1) == niz_ga.get(i1)) i++;
            }
            if(i >= 2) return true;
            else return false;
   }

  public boolean najteziRomb(String domacin, String gost, int metoda)
   {
          //ako je metoda 1 onda je u pitanju romb 3 sa desne strane
        //ako je metoda -1 onda je u pitanju romb 4 sa desne strane
        boolean t1 = false;
        
        double goalT1 = 0;
        double goalT2 = 0;      
        double b3T1 = 0;
        double b3T2 = 0;
        double b8T1 = 0;
        double b8T2 = 0;
                
        for(short i = 0; i<niz_kod.size(); i++)
        {
            if(niz_home.get(i).equals(domacin))
            {
                goalT1 += niz_gh.get(i);
                goalT2 += niz_ga.get(i);
                b3T1 += ((niz_goloviHpoluvreme.get(i)/5.0)*20 - 10);
                b3T2 += ((niz_goloviApoluvreme.get(i)/5.0)*20 - 10);
                b8T1 += (((niz_faulH.get(i)-1)/32.0)*20 - 10);
                b8T2 +=  (((niz_faulA.get(i)-1)/25.0)*20 - 10);
                b8T1 += ((niz_korneH.get(i)) - 10);
                b8T2 += (((niz_korneA.get(i))/19.0)*20 - 10);
                b8T1 += (((niz_zutiH.get(i))/7.0)*20 - 10);
                b8T2 += ((niz_zutiA.get(i))*20 - 10);
                b8T1 += 3*(((niz_crveniH.get(i))/2.0)*20 - 10);
                b8T2 += 3*(((niz_crveniA.get(i))/2.0)*20 - 10);
            }
            else if(niz_away.get(i).equals(domacin))
            {
                goalT1 += niz_ga.get(i);
                goalT2 += niz_gh.get(i);
                b3T2 += ((niz_goloviHpoluvreme.get(i)/5.0)*20 - 10);
                b3T1 += ((niz_goloviApoluvreme.get(i)/5.0)*20 - 10);
                b8T2 += (((niz_faulH.get(i)-1)/32.0)*20 - 10);
                b8T1 +=  (((niz_faulA.get(i)-1)/25.0)*20 - 10);
                b8T2 += ((niz_korneH.get(i)) - 10);
                b8T1 += (((niz_korneA.get(i))/19.0)*20 - 10);
                b8T2 += (((niz_zutiH.get(i))/7.0)*20 - 10);
                b8T1 += ((niz_zutiA.get(i))*20 - 10);
                b8T2 += 3*(((niz_crveniH.get(i))/2.0)*20 - 10);
                b8T1 += 3*(((niz_crveniA.get(i))/2.0)*20 - 10);
            }
        }
        double avgT1 = goalT1/ (niz_kod.size()*1.0);
        double avgT2 = goalT2/ (niz_kod.size()*1.0);
        b3T1 = b3T1 / (niz_kod.size()*1.0);
        b3T2 = b3T2 / (niz_kod.size()*1.0);
        b8T1 = b8T1 / (niz_kod.size()*1.0);
        b8T2 = b8T2 / (niz_kod.size()*1.0);
        
        if(metoda == 1)
        {
                if(avgT1 > avgT2 && b3T1 >= b3T2 && b8T1 >= b8T2)
                {
                    t1 = true;
                }
        }
        else
        {
                if(avgT1 <= avgT2 && b3T1 <= b3T2 && b8T1 <= b8T2)
                {
                    t1 = true;
                }
        }
        
        return t1;
   }
   
   public boolean goloviIKartoni(String domacin, String gost, int metoda)
    {
        //ako je metoda 1 onda je u pitanju gornji romb sa desne strane
        //ako je metoda -1 onda je u pitanju donji romb sa desne strane
        boolean t1 = false;
        
        double goalT1 = 0;
        double goalT2 = 0;
        double crvenikartonT1 = 0;
        double crvenikartonT2 = 0;
        double zutikartonT1 = 0;
        double zutikartonT2 = 0;
        for(short i = 0; i<niz_kod.size(); i++)
        {
            if(niz_home.get(i).equals(domacin))
            {
                goalT1 += niz_gh.get(i);
                goalT2 += niz_ga.get(i);
                crvenikartonT1 += niz_crveniH.get(i);
                crvenikartonT2 += niz_crveniA.get(i);
                zutikartonT1 += niz_zutiH.get(i);
                zutikartonT2 += niz_zutiA.get(i);
            }
            else if(niz_away.get(i).equals(domacin))//da, odoh,, ae pavanje :*
            {
                goalT1 += niz_ga.get(i);
                goalT2 += niz_gh.get(i);
                crvenikartonT1 += niz_crveniA.get(i);
                crvenikartonT2 += niz_crveniH.get(i);
                zutikartonT1 += niz_zutiA.get(i);
                zutikartonT2 += niz_zutiH.get(i);
            }
        }
        double avgT1 = goalT1/ (niz_kod.size()*1.0);
        double avgT2 = goalT2/ (niz_kod.size()*1.0);
        double avgK1 = (3*crvenikartonT1 + zutikartonT1) / (niz_kod.size()*1.0);
        double avgK2 = (3*crvenikartonT2 + zutikartonT2)/ (niz_kod.size()*1.0);
              
        if(metoda == 1)
        {
                if(avgT1 > avgT2 && avgK1 < avgK2)
                {
                    t1 = true;
                }
        }
        else
        {
                if(avgT1 <= avgT2 && avgK1 >= avgK2)
                {
                    t1 = true;
                }
        }
        
        return t1;
    }

   public boolean dalVoleSudijaDomace()
   {
       boolean t = false;
       HashMap<String, int[]> mapa = new HashMap<String, int[]>();
              Scanner fileIn = null;
		try {
			fileIn = new Scanner(new File("izlazSudije.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn.hasNext())
		{
			String line = fileIn.nextLine();
			String pom[] = line.split(",");
                        int[] niz = new int[3];
                        niz[0] = Integer.parseInt(pom[1]);
                        niz[1] = Integer.parseInt(pom[2]);
                        niz[2] = Integer.parseInt(pom[3]);
                        mapa.put(pom[0], niz);
                }
           
        int zbirDomaciPobede = 0;
        int zbirGostiPobede = 0;
        int zbirNereseno = 0;
       for(int i = 0; i < niz_kod.size(); i++)
       {
               zbirDomaciPobede += mapa.get(niz_sudije.get(i))[0];
               zbirGostiPobede += mapa.get(niz_sudije.get(i))[2];
               zbirNereseno += mapa.get(niz_sudije.get(i))[1];
       }
       
       if(zbirDomaciPobede*2 > (zbirGostiPobede + zbirNereseno)) t = true;
                
       return t;         
   }
   
   public boolean kvota(String tim)
    {
        boolean t1 = false;
        double kvota = 0;
        
        for(int i = 0; i < niz_kod.size();++i)
        {
            if(niz_home.get(i).equals(tim))
            {
                kvota  +=  niz_kvoteH.get(i);
            }
            else
                kvota  += niz_kvoteA.get(i); 
        }
        double AVG = kvota/(niz_kod.size()*1.00);
        if(AVG < 1.75)
            return true;
        return t1;
    }
   
    public short ishod(List<Integer> utakmice,String domaci, String gosti)
    {
        short brojacd = 0;
        short brojacg = 0;
        short brojnereseno = 0; 
                
                for(int i = 0; i < utakmice.size(); ++i)
                {
                    if((niz_home.get(i).equals(domaci) && niz_away.get(i).equals(gosti)))
                    {
                        if(niz_gh.get(i) > niz_ga.get(i)) ++brojacd;
                        else if(niz_gh.get(i) < niz_ga.get(i)) ++brojacg; 
                        else ++brojnereseno;
                    }
                    else 
                    {
                        if(niz_ga.get(i) > niz_gh.get(i)) ++brojacd;  
                        else if(niz_ga.get(i) < niz_gh.get(i)) ++brojacg;
                        else ++brojnereseno;
                    }
                }
             
        //System.out.println("Nereseno " + brojnereseno + "domacin " + brojacd + "gost" + brojacg);
        if(((double)brojacd * 2) > (brojacg + brojnereseno))
            return 1;
        else if(((double)brojacg * 2) > ( brojacd + brojnereseno))
            return 2;
        else if(((double)brojnereseno * 2) > ( brojacd + brojacg))
            return 0;
        else 
            return -1;
    }
    
    public short utakmice4pobedik(List<Integer> utakmice,String domaci, String gosti){
   
            int index1 = 0;
            int index2 = 0;
            int index3 = 0;
            int index4 = 0;
            
            for(int i = 1; i < utakmice.size(); ++i)
            {
                String pom1[] = niz_kod.get(i).split("/");
                String pom2[] = niz_kod.get(index1).split("/");
                if(Integer.parseInt(pom1[2].trim()) >= Integer.parseInt(pom2[2].trim()))
                {
                    index1 = i;
                }
               
            }
            
            
            for(int i = 1; i < utakmice.size(); ++i)
            {
                String pom1[] = niz_kod.get(i).split("/");
                String pom2[] = niz_kod.get(index2).split("/");
                if(Integer.parseInt(pom1[2].trim()) >= Integer.parseInt(pom2[2].trim()) && i != index1)
                {
                    index2 = i;
                }
               
            }
            
            for(int i = 1; i < utakmice.size(); ++i)
            {
                String pom1[] = niz_kod.get(i).split("/");
                String pom2[] = niz_kod.get(index3).split("/");
                if(Integer.parseInt(pom1[2].trim()) >= Integer.parseInt(pom2[2].trim()) && i != index1 && i!=index2)
                {
                    index3 = i;
                }
               
            }
            
            for(int i = 1; i < utakmice.size(); ++i)
            {
                String pom1[] = niz_kod.get(i).split("/");
                String pom2[] = niz_kod.get(index4).split("/");
                if(Integer.parseInt(pom1[2].trim()) >= Integer.parseInt(pom2[2].trim()) && i != index1 && i!=index2 && i!=index3)
                {
                    index4 = i;
                }
               
            }
            
            /*System.out.println("Prva godina"+ niz_kod.get(index1));
            System.out.println("Druga godina"+ niz_kod.get(index2));
            System.out.println("Treca godina"+ niz_kod.get(index3));
            System.out.println("Cetvrta godina"+ niz_kod.get(index4));*/
            
            short brojacd = 0;
            short brojacg = 0;
            short brojnereseno = 0;
            //Arsenal - Chelsea
            //Chelsea - Arsenal
            /*System.out.println("TIJANINOOO");
            System.out.println(niz_home.get(index1)+" "+niz_away.get(index1)+" "+niz_gh.get(index1)+" "+niz_ga.get(index1));
            System.out.println(niz_home.get(index2)+" "+niz_away.get(index2)+" "+niz_gh.get(index2)+" "+niz_ga.get(index2));
            System.out.println(niz_home.get(index3)+" "+niz_away.get(index3)+" "+niz_gh.get(index3)+" "+niz_ga.get(index3));
            System.out.println(niz_home.get(index4)+" "+niz_away.get(index4)+" "+niz_gh.get(index4)+" "+niz_ga.get(index4));*/
            if(niz_home.get(index1).equals(domaci))
            {
                 if(niz_gh.get(index1) > niz_ga.get(index1)) ++brojacd;
                 else if(niz_gh.get(index1) < niz_ga.get(index1)) ++brojacg; 
                 else ++brojnereseno;
            }
            else
            {
                if(niz_ga.get(index1) > niz_gh.get(index1)) ++brojacd;  
                else if(niz_ga.get(index1) < niz_gh.get(index1)) ++brojacg;
                else ++brojnereseno;
            }
            
            if(niz_home.get(index2).equals(domaci))
            {
                 if(niz_gh.get(index2) > niz_ga.get(index2)) ++brojacd;
                 else if(niz_gh.get(index2) < niz_ga.get(index2)) ++brojacg;
                 else ++brojnereseno;
            }
            else
            {
                if(niz_ga.get(index2) > niz_gh.get(index2)) ++brojacd;  
                else if(niz_ga.get(index2) < niz_gh.get(index2)) ++brojacg;
                else ++brojnereseno;
            }
            
            if(niz_home.get(index3).equals(domaci))
            {
                 if(niz_gh.get(index3) > niz_ga.get(index3)) ++brojacd;
                 else if(niz_gh.get(index3) < niz_ga.get(index3)) ++brojacg;
                 else ++brojnereseno;
            }
            else
            {
                if(niz_ga.get(index3) > niz_gh.get(index3)) ++brojacd;  
                else if(niz_ga.get(index3) < niz_gh.get(index3)) ++brojacg;
                else ++brojnereseno;
            }
                        
            if(niz_home.get(index4).equals(domaci))
            {
                 if(niz_gh.get(index4) > niz_ga.get(index4)) ++brojacd;
                 else if(niz_gh.get(index4) < niz_ga.get(index4)) ++brojacg;
                 else ++brojnereseno;
            }
            else
            {
                if(niz_ga.get(index4) > niz_gh.get(index4)) ++brojacd;  
                else if(niz_ga.get(index4) < niz_gh.get(index4)) ++brojacg;
                else ++brojnereseno;
            }
            //System.out.println("brojac jeee   "+brojnereseno);
            if(brojacd == 3)
                return 1;
            else if(brojacg == 3)
                return 2;
            else if(brojnereseno == 3)
                return 0;
            else 
                return -1;
    }
    
    
}
