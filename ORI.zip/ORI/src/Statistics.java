
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.Math.pow;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.neuroph.core.NeuralNetwork;
import org.neuroph.core.learning.DataSet;
import org.neuroph.nnet.MultiLayerPerceptron;
import org.neuroph.nnet.learning.MomentumBackpropagation;
import org.neuroph.util.TrainingSetImport;
import org.neuroph.util.TransferFunctionType;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kokoliko
 */
public class Statistics extends JFrame {
     
    LanguageHandle l = new LanguageHandle();
    private String s3 = "2016/2017 : ";
  
    private JLabel lag = new JLabel(l.getLaG_default());
    private JLabel reg = new JLabel(l.getReg_default());
    private JLabel nnreg = new JLabel("NNR");
    private JLabel treeDecLabel = new JLabel("TreeDecision");
    private JLabel randomLabel = new JLabel("Random forrest");
    private JLabel nLabel = new JLabel("Neural network");
     List<Double> niz_MR = new ArrayList<Double>();
     List<Integer> niz_MRHW = new ArrayList<Integer>();
     List<Integer> niz_MRX = new ArrayList<Integer>();
     List<Integer> niz_MRAW = new ArrayList<Integer>();
    double[] x = new double[68];
            int k;
 

        double y[] = new double[68];
        double reZ1=0,rezX=0,reZ2=0;
        int tacno;
    
    private JLabel lag2016 = new JLabel(s3);
    private JLabel reg2016 = new JLabel(s3);
    private JLabel nnreg2016 = new JLabel(s3);
      private JLabel tree2016 = new JLabel(s3);
    private JLabel random2016 = new JLabel(s3);
    private JLabel n2016 = new JLabel(s3);
    
    private int koef;
    private int stepen;
    
    private double[] rez2;
    private int brojUtakmica = 0;
        
    int brojL = 0;
    int brojR = 0;
    int brojNN = 0;
     
    public Statistics(List<Double> niz_MR, List<Integer> niz_MRHW, List<Integer> niz_MRX, List<Integer> niz_MRAW, int stepen, int koef) {
        super("");
        this.niz_MRHW = niz_MRHW;
        this.niz_MRX = niz_MRX;
        this.niz_MRAW = niz_MRAW;
        this.niz_MR = niz_MR;
        this.stepen = stepen;
        this.koef = koef;
       for(short i1 = 0; i1 < niz_MRHW.size(); i1++) x[i1] = niz_MR.get(i1);
        int i = 0;
        
        // create a new panel with GridBagLayout manager
        JPanel newPanel = new JPanel(new GridBagLayout());
         
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(10, 10, 10, 10);
         
        // add components to the panel
        
        rez2 = Calculate(2016);
        
        JLabel lag2016 = new JLabel(s3+" "+rez2[0]+ " %");
        JLabel reg2016 = new JLabel(s3+" "+rez2[1]+ " %");
        JLabel nnreg2016 = new JLabel(s3+" "+rez2[2]+" %");
        JLabel tree2016 = new JLabel(s3+" "+rez2[3]+ " %");
        JLabel random2016 = new JLabel(s3+" "+rez2[4]+" %");
        JLabel n2016 = new JLabel(s3+" "+rez2[5]+" %");
        
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(lag, constraints);
        
        constraints.gridx = 0;
        constraints.gridy = 3;     
        newPanel.add(lag2016, constraints);
       
        
        constraints.gridx = 3;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(reg, constraints);
        
   
        constraints.gridx = 3;
        constraints.gridy = 3;     
        newPanel.add(reg2016, constraints);
         
        
        constraints.gridx = 5;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(nnreg, constraints);
        
        
        constraints.gridx = 5;
        constraints.gridy = 3;     
        newPanel.add(nnreg2016, constraints);
        
        
        
        constraints.gridx = 7;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(treeDecLabel, constraints);
        
        
        constraints.gridx = 7;
        constraints.gridy = 3;     
        newPanel.add(tree2016, constraints);
        
        
        constraints.gridx = 9;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(randomLabel, constraints);
        
        
        constraints.gridx = 9;
        constraints.gridy = 3;     
        newPanel.add(random2016, constraints);
        
        
                constraints.gridx = 11;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        newPanel.add(nLabel, constraints);
        
        
        constraints.gridx = 11;
        constraints.gridy = 3;     
        newPanel.add(n2016, constraints);
         
        // add the panel to this frame
        add(newPanel);
         
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private double[] Calculate(int sezona)
    {
        double[] rez = new double[6];               // Lagr. regresija  2014 2015 2016 suma
         FileManip f = new FileManip();                            //klasa za manipulaciju fajlom(upis, citanje)
    
    List<String> niz_kod = new ArrayList<String>();       //lista datuma
    List<Integer> niz_gh = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_ga = new ArrayList<Integer>();        //lista datih golova gosta
    List<String> niz_home = new ArrayList<String>();        //lista imena domacina
    List<String> niz_away = new ArrayList<String>();        //lista imena gostiju
    List<Integer> niz_goloviHpoluvreme = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_goloviApoluvreme = new ArrayList<Integer>();        //lista datih golova gosta
    List<Integer> niz_suteviH = new ArrayList<Integer>();        //lista imena domacina
    List<Integer> niz_suteviA = new ArrayList<Integer>();        //lista imena gostiju
    List<Integer> niz_suteviOkvirH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_suteviOkvirA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_korneH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_korneA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_zutiH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_zutiA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_crveniH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_crveniA = new ArrayList<Integer>();        //lista datih golova gosta
        List<Integer> niz_faulH = new ArrayList<Integer>();        //lista datih golova domacina
    List<Integer> niz_faulA = new ArrayList<Integer>();        //lista datih golova gosta
    
    List<Double> niz_kvoteH = new ArrayList<Double>();
    List<Double> niz_kvoteX = new ArrayList<Double>();
    List<Double> niz_kvoteA = new ArrayList<Double>();
    
    List<String> niz_sudije = new ArrayList<String>();

        List<String> niz_za_upis = new ArrayList<String>();     //lista koju saljem klasi File da upise torke iz baze u fajl
        String ekipe[] = new String [20];                       //niz ekipa sezone 
        
       if(sezona == 2016)
        {
            ekipe[0]="Hull";
            ekipe[1]="Burnley";
            ekipe[2]="Middlesbrough";
            ekipe[3]="Man City";
            ekipe[4]="Bournemouth";
            ekipe[5]="Chelsea";
            ekipe[6]="Crystal Palace";
            ekipe[7]="Everton";
            ekipe[8]="Southampton";
            ekipe[9]="Arsenal";
            ekipe[10]="Man United";
            ekipe[11]="Stoke";
            ekipe[12]="Watford";
            ekipe[13]="Swansea";
            ekipe[14]="Leicester";
            ekipe[15]="Sunderland";
            ekipe[16]="Tottenham";
            ekipe[17]="West Ham";
            ekipe[18]="West Brom";
            ekipe[19]="Liverpool";
        }
       
        String[] s = f.loadText("M1.txt");
        
        int brojacUtakmicaL = 0;
        int brojacLagranzP = 0;
        
        int brojacUtakmicaR = 0;
        int brojacRegP = 0;

        int brojacUtakmicaNNN = 0;
        int brojacNNNP = 0;
        
        int brojacUtakmica = 0;
  
        int brojacTree = 0;
        int brojacNeuronska = 0;
        int brojacRandom = 0;
        
        String domacin,gost;
        
                              /* String trainingSetFileName = "izlazNeuronskaTrening.txt";
                        int inputsCount = 8;
                         int outputsCount = 3;
                                 // create training set
                DataSet trainingSet = null;
                try {
                    trainingSet = TrainingSetImport.importFromFile(trainingSetFileName, inputsCount, outputsCount, ",");
                } catch (FileNotFoundException ex) {
                    System.out.println("File not found!");
                } catch (IOException | NumberFormatException ex) {
                    System.out.println("Error reading file or bad number format!");
                }
                
                                // create multi layer perceptron
                 System.out.println("Creating neural network");
                 MultiLayerPerceptron neuralNet = new MultiLayerPerceptron(TransferFunctionType.SIGMOID, 8, 30, 3);

                 // set learning parametars
                 MomentumBackpropagation learningRule = (MomentumBackpropagation) neuralNet.getLearningRule();
                 learningRule.setLearningRate(0.3);
                 learningRule.setMomentum(0.7);

                 // learn the training set
                 System.out.println("Training neural network...");
                 neuralNet.learn(trainingSet);
                 System.out.println("Done!");
                 neuralNet.save("neuronska1");*/
                    NeuralNetwork neuralNet = MultiLayerPerceptron.load("neuronska1");
                    
        for(int i = 0; i < 20 ; ++i)
        {
            domacin = ekipe[i];     //uzimam domacu ekipu
                   for(int j = 0; j < 20; ++j)      //prolazim kroz sve gostujuce (pravim parove programski)
                   {
                       k = 0;

                       gost = ekipe[j]; //uzimam gosta
                 niz_kod.clear();
                niz_home.clear();
                niz_away.clear();
                niz_gh.clear();
                niz_ga.clear();
                niz_goloviHpoluvreme.clear();
                niz_goloviApoluvreme.clear();
                niz_suteviH.clear();
                niz_suteviA.clear();
                niz_suteviOkvirH.clear();
                niz_suteviOkvirA.clear();
                niz_korneH.clear();
                niz_korneA.clear();
                niz_zutiH.clear();
                  niz_zutiA.clear();
                  niz_crveniH.clear();
                niz_crveniA.clear();
                niz_sudije.clear();
                niz_kvoteH.clear();
                niz_kvoteX.clear();
                niz_kvoteA.clear();
                niz_faulH.clear();
                niz_faulA.clear();
                
                       if (i!=j)    //racunam samo ako su razlicite ekipe u pitanju
                       {
                           
                           for(int p = 0; p<s.length; p++)
                           {
                               String[] parts = s[p].split(",");
                               
                                if((parts[2].equals(ekipe[i]) && parts[3].equals(ekipe[j])))      //poredim da li je selektovana bas ta torka baze (domacin i gost)
                                {
                                    String s1 = parts[1].substring(3,4);
                                    String s2 = parts[1].substring(6);
                                    int mesec = Integer.parseInt(s1);
                                    int godina = Integer.parseInt(s2)+2000;
                                    if(godina < sezona || (godina == sezona && mesec < 8))
                                    {   
                                        niz_kod.add(parts[1]);
                                        niz_home.add(parts[2]);
                                        niz_away.add(parts[3]);
                                        niz_gh.add(Integer.parseInt(parts[4]));
                                        niz_ga.add(Integer.parseInt(parts[5]));
                                        niz_goloviHpoluvreme.add(Integer.parseInt(parts[7]));
                                        niz_goloviApoluvreme.add(Integer.parseInt(parts[8]));
                                        niz_suteviH.add(Integer.parseInt(parts[11]));
                                        niz_suteviA.add(Integer.parseInt(parts[12]));
                                        niz_suteviOkvirH.add(Integer.parseInt(parts[13]));
                                        niz_suteviOkvirA.add(Integer.parseInt(parts[14]));
                                        niz_faulH.add(Integer.parseInt(parts[15]));
                                        niz_faulA.add(Integer.parseInt(parts[16]));
                                        niz_korneH.add(Integer.parseInt(parts[17]));
                                        niz_korneA.add(Integer.parseInt(parts[18]));
                                        niz_zutiH.add(Integer.parseInt(parts[19]));
                                        niz_zutiA.add(Integer.parseInt(parts[20]));
                                        niz_crveniH.add(Integer.parseInt(parts[21]));
                                        niz_crveniA.add(Integer.parseInt(parts[22]));
                                        niz_sudije.add(parts[10]);
                                        niz_kvoteH.add(Double.parseDouble(parts[23]));
                                        niz_kvoteX.add(Double.parseDouble(parts[24]));
                                        niz_kvoteA.add(Double.parseDouble(parts[25]));
                                        k++;
                                    } 
                                    else
                                    {
                                        tacno = Integer.parseInt(parts[4]) - Integer.parseInt(parts[5]);
                                    }
                                }
                                else if((parts[3].equals(ekipe[i]) && parts[2].equals(ekipe[j])))
                                {
                                    String s1 = parts[1].substring(3,4);
                                    String s2 = parts[1].substring(6);
                                    int mesec = Integer.parseInt(s1);
                                    int godina = Integer.parseInt(s2)+2000;
                                    if(godina < sezona || (godina == sezona && mesec < 8))
                                    {   
                                        niz_kod.add(parts[1]);
                                        niz_home.add(parts[2]);
                                        niz_away.add(parts[3]);
                                        niz_gh.add(Integer.parseInt(parts[4]));
                                        niz_ga.add(Integer.parseInt(parts[5]));
                                        niz_goloviHpoluvreme.add(Integer.parseInt(parts[7]));
                                        niz_goloviApoluvreme.add(Integer.parseInt(parts[8]));
                                        niz_suteviH.add(Integer.parseInt(parts[11]));
                                        niz_suteviA.add(Integer.parseInt(parts[12]));
                                        niz_suteviOkvirH.add(Integer.parseInt(parts[13]));
                                        niz_suteviOkvirA.add(Integer.parseInt(parts[14]));
                                        niz_faulH.add(Integer.parseInt(parts[15]));
                                        niz_faulA.add(Integer.parseInt(parts[16]));
                                        niz_korneH.add(Integer.parseInt(parts[17]));
                                        niz_korneA.add(Integer.parseInt(parts[18]));
                                        niz_zutiH.add(Integer.parseInt(parts[19]));
                                        niz_zutiA.add(Integer.parseInt(parts[20]));
                                        niz_crveniH.add(Integer.parseInt(parts[21]));
                                        niz_crveniA.add(Integer.parseInt(parts[22]));
                                        niz_sudije.add(parts[10]);
                                        niz_kvoteH.add(Double.parseDouble(parts[23]));
                                        niz_kvoteX.add(Double.parseDouble(parts[24]));
                                        niz_kvoteA.add(Double.parseDouble(parts[25]));
                                        k++;
                                    }
                                   
                                   
                                }
                                    
                           }
                           
                           if(k != 0)
                           {  
                               brojacUtakmica++;
                               double mr = 0;
                                mr = izracunajMR(sezona,domacin,k,niz_kod,niz_home,niz_away,niz_gh,niz_ga,niz_goloviHpoluvreme,niz_goloviApoluvreme,niz_suteviH,niz_suteviA,niz_suteviOkvirH,niz_suteviOkvirA,niz_faulH,niz_faulA,niz_korneH,niz_korneA,niz_zutiH,niz_zutiA,niz_crveniH,niz_crveniA,niz_kvoteH,niz_kvoteX,niz_kvoteA);
                                double rez1[] = Lagranz(mr,domacin,gost);
                                //if(sezona == 2015)System.out.println(rez1[0]+" "+rez1[1]+" "+rez1[2]);
                                //if(rez1[0] > rez1[1]+rez1[2] || rez1[1] > rez1[2]+rez1[0] || rez1[2] > rez1[1]+rez1[0])
                                //{   brojacL++;
                                double rez01[] = new double[3];
                                rez01[0] = Math.abs(rez1[0]);
                                rez01[1] = Math.abs(rez1[1]);
                                rez01[2] = Math.abs(rez1[2]);
                                if(rez01[0] > rez01[1] && rez01[0] > rez01[2] && rez01[0] >= rez01[1]+rez01[2] )
                                {
                                    brojacUtakmicaL++;
                                    if(tacno > 0)   brojacLagranzP++;
                                }
                                
                                if(rez01[1] > rez01[0] && rez01[1] > rez01[2] && rez01[1] >= rez01[0]+rez01[2])
                                {
                                    brojacUtakmicaL++;
                                    if(tacno == 0)   brojacLagranzP++;
                                }
                                                                
                                if(rez01[2] > rez01[1] && rez01[2] > rez01[0] && rez01[2] >= rez01[1]+rez01[0])
                                {
                                    brojacUtakmicaL++;
                                    if(tacno < 0)   brojacLagranzP++;
                                }
                               // }
                                
                                double rez2[] = Regresija(mr,domacin,gost);
                                double rez02[] = new double[3];
                                rez02[0] = Math.abs(rez2[0]);
                                rez02[1] = Math.abs(rez2[1]);
                                rez02[2] = Math.abs(rez2[2]);
                                 //if(rez2[0] > rez2[1]+rez2[2] || rez2[1] > rez2[2]+rez1[0] || rez2[2] > rez2[1]+rez2[0])
                                 //{
                                 //brojacP++;   
                                if(rez02[0] > rez02[1] && rez02[0] > rez02[2] && rez02[0] >= rez02[1]+rez02[2])
                                {
                                    brojacUtakmicaR++;
                                    if(tacno > 0)   brojacRegP++;
                                }
                                
                                if(rez02[1] > rez02[0] && rez02[1] > rez02[2] && rez02[1] >= rez02[0]+rez02[2])
                                {
                                    brojacUtakmicaR++;
                                    if(tacno == 0)   brojacRegP++;
                                }
                                                                
                                if(rez02[2] > rez02[1] && rez02[2] > rez02[0] && rez02[2] >= rez02[1]+rez02[0])
                                {
                                    brojacUtakmicaR++;
                                    if(tacno < 0)   brojacRegP++;
                                }
                                 //}
                                
                                 double rez3[] = NNReg(mr,domacin,gost);
                                
                                 
                                 if(rez3[0] > rez3[1] && rez3[0] > rez3[2] && rez3[0]*1.1 >= rez3[1]+rez3[2])
                                {
                                    brojacUtakmicaNNN++;
                                    if(tacno > 0)   brojacNNNP++;
                                }
                                
                                if(rez3[1] > rez3[0] && rez3[1] > rez3[2] && rez3[1]*1.1 >= rez3[0]+rez3[2])
                                {
                                    brojacUtakmicaNNN++;
                                    if(tacno == 0)   brojacNNNP++;
                                }
                                                                
                                if(rez3[2] > rez3[1] && rez3[2] > rez3[0] && rez3[2]*1.1 >= rez3[1]+rez3[0])
                                {
                                    brojacUtakmicaNNN++;
                                    if(tacno < 0)   brojacNNNP++;
                                }
                                
                            TreeDecision tr = new TreeDecision(niz_kod,niz_gh,niz_ga,niz_home,niz_away,niz_goloviHpoluvreme,niz_goloviApoluvreme,niz_suteviH,niz_suteviA,niz_suteviOkvirH,
                            niz_suteviOkvirA,niz_korneH,niz_korneA,niz_zutiH,niz_zutiA,niz_crveniH,niz_crveniA,niz_faulH,niz_faulA,niz_kvoteH,niz_kvoteX,niz_kvoteA,niz_sudije);
                            short treeRez = tr.racunaj(domacin, gost);
                            if(treeRez == 1 && tacno > 0) {brojacTree++; /*System.out.println("POGODAK");*/}
                            else  if(treeRez == 2 && tacno < 0) {brojacTree++; /*System.out.println("POGODAK");*/}
                            else if(treeRez == 0 && tacno == 0) {brojacTree++; /*System.out.println("POGODAK");*/}
                            
                            double[] d = neuronska(domacin, gost, neuralNet);
                             if(d[0] > d[1] && d[0] > d[2] && tacno > 0) { brojacNeuronska++;}
                             else if(d[1] > d[2] && d[1] > d[0] && tacno == 0){  brojacNeuronska++;}
                             else if(d[2] > d[0] && d[2] > d[1] && tacno < 0) { brojacNeuronska++;}
                            
                             
                             RandomForrest rf = new RandomForrest(niz_kod,niz_gh,niz_ga,niz_home,niz_away,niz_goloviHpoluvreme,niz_goloviApoluvreme,niz_suteviH,niz_suteviA,niz_suteviOkvirH,
                            niz_suteviOkvirA,niz_korneH,niz_korneA,niz_zutiH,niz_zutiA,niz_crveniH,niz_crveniA,niz_faulH,niz_faulA,niz_kvoteH,niz_kvoteX,niz_kvoteA,niz_sudije);
                            int randRez = rf.result(domacin, gost,17);
                            if(randRez == 1 && tacno > 0) {brojacRandom++;}
                            else  if(randRez == 2 && tacno < 0) {brojacRandom++; }
                            else if(randRez == 0 && tacno == 0) {brojacRandom++;}
                             
                           }
 
                       }
                       
                   }
        }
               
        rez[0] = (double)((brojacLagranzP/(double)brojacUtakmicaL)*100.0);
        rez[0] = Math.round(rez[0]*100.0)/100.0;
        rez[1] = (double)((brojacRegP/(double)brojacUtakmicaR)*100.0);
        rez[1] = Math.round(rez[1]*100.0)/100.0;
        rez[2] = (double)((brojacNNNP/(double)brojacUtakmicaNNN)*100.0);
        rez[2] = Math.round(rez[2]*100.0)/100.0;
        rez[3] = (double)((brojacTree/(double)brojacUtakmica)*100.0);
        rez[3] = Math.round(rez[3]*100.0)/100.0;
        rez[4] = (double)((brojacRandom/(double)brojacUtakmica)*100.0);
        rez[4] = Math.round(rez[4]*100.0)/100.0;
        rez[5] = (double)((brojacNeuronska/(double)brojacUtakmica)*100.0);
        rez[5] = Math.round(rez[5]*100.0)/100.0;
        this.brojUtakmica = brojacUtakmica;
        return rez;
    }
    
    private double izracunajMR(int sezona, String domacin, int j, List<String> niz_kod, List<String> niz_home, List<String> niz_away, List<Integer> niz_gh, List<Integer> niz_ga, List<Integer> niz_goloviHpoluvreme, List<Integer> niz_goloviApoluvreme, List<Integer> niz_suteviH, List<Integer> niz_suteviA, List<Integer> niz_suteviOkvirH, List<Integer> niz_suteviOkvirA, List<Integer> niz_faulH, List<Integer> niz_faulA, List<Integer> niz_korneH, List<Integer> niz_korneA, List<Integer> niz_zutiH, List<Integer> niz_zutiA, List<Integer> niz_crveniH, List<Integer> niz_crveniA, List<Double> niz_kvoteH, List<Double> niz_kvoteX, List<Double> niz_kvoteA)
    {
            double mr = 0;       //inicijalno MR je 0
           double sum = 0;
            for(int k = 0; k<j; k++) 
            {
                //ispis utakmica koje su trazene
                //System.out.println(niz_kod.get(k)+" "+niz_home.get(k)+" "+niz_away.get(k)+" "+niz_gh.get(k)+" "+niz_ga.get(k));     //ispis u konzolu
                String str = niz_kod.get(k).substring(6);
                int god = Integer.parseInt(str)+2000;         //godina(sezona) igranja utakmice
                int gh = niz_gh.get(k);
                int ga = niz_ga.get(k);               
                int golHpoluvreme =  niz_goloviHpoluvreme.get(k);
                int golApoluvreme =  niz_goloviApoluvreme.get(k);
                int sutH = niz_suteviH.get(k);
                int sutA = niz_suteviA.get(k);
                int sutokvirH = niz_suteviOkvirH.get(k);
                int sutokvirA = niz_suteviOkvirA.get(k);
                int faulH = niz_faulH.get(k);
                int faulA = niz_faulA.get(k);
                int kornerH = niz_korneH.get(k);
                int kornerA = niz_korneA.get(k);
                int zutiH = niz_zutiH.get(k);
                int zutiA = niz_zutiA.get(k);
                int crveniH = niz_crveniH.get(k);
                int crveniA = niz_crveniA.get(k);
                double kvotaH = niz_kvoteH.get(k);
                double kvotaX = niz_kvoteX.get(k);
                double kvotaA = niz_kvoteA.get(k);
               
                
                double b1 = (gh/9.0)*20 - 10;
                double b2 = (ga/7.0)*20 - 10;
                double b31 = 0.5*((golHpoluvreme/5.0)*20 - 10);
                double b32 = 0.5*((golApoluvreme/5.0)*20 - 10);
                double b4 = ((sutH-1)/42.0)*20 - 10;
                double b5 = (sutA/30.0)*20 - 10;
                double b6 = (sutokvirH/24.0)*20 - 10;
                double b7 = (sutokvirA/20.0)*20 - 10;
                double b81 = 0.125*(((faulH-1)/32.0)*20 - 10);
                double b82 = 0.125*(((faulA-1)/25.0)*20 - 10);
                double b83 = 0.125*((kornerH/20.0)*20 - 10);
                double b84 = 0.125*(((kornerA-0)/19.0)*20 - 10);
                double b85 = 0.125*(((zutiH-0)/7.0)*20 - 10);
                double b86 = 0.125*((zutiA/9.0)*20 - 10);
                double b87 = 0.125*(((crveniH-0)/2.0)*20 - 10);
                double b88 = 0.125*(((crveniA-0)/2.0)*20 - 10);
                double b9 = ((20/(17-1.09))*(kvotaH - 17) + 10)*(-1);
                double b10 = ((20/(29-1.16))*(kvotaA - 29) + 10)*(-1);
                double b3 = (b31+b32)/2.0;                
                double b8 = (b81+b82+b83+b84+b85+b86+b87+b88)/8.0;

                
                //racunanje
                if(niz_home.get(k).equals(domacin))
                {
                  sum += ((b1+b2+b3+b4+b5+b6+b7+b8+b9+b10)/10.0);
                  sum += (Math.abs(sum+3)*(1-(2016-god)*0.06));
                    //Random r = new Random();
                    //sum += r.nextDouble()%(0.1);         //random faktor(vrlo mali)
                }
                else
                {
                    sum += (b1+b2+b3+b4+b5+b6+b7+b8+b9+b10)/10.0;      
                    sum += Math.abs(sum+3)*(1-(2016-god)*0.06);
                    //Random r = new Random();
                    //sum -= r.nextDouble()%(0.1);     //random faktor(vrlo mali)
                }
        
            }
            mr = sum/j;
             return mr;
    }
    
    double[] Lagranz(double mr, String domacin, String gost)
    {
                double polinom1[] = new double[niz_MRHW.size()];
        double polinomX[] = new double[niz_MRHW.size()];
        double polinom2[] = new double[niz_MRHW.size()];
        LagrangeInterpolation LI = new LagrangeInterpolation(); 
        
               for(int i = 0; i < niz_MRHW.size(); i++) y[i] = (double)niz_MRHW.get(i);         //uzimamo vrednosti y iz lista    
               polinom1 = LI.findPolynomialFactors(x, y);                   //nalazimo polinom
               double s1 = 0;                                               //vrednost polinoma u tacki MR koju smo sracunali ce biti ovde
               int j1 = polinom1.length-1;                                  //stepen polinoma-1
               for(int i = 0; i < polinom1.length; i++)
               {
                    s1 += polinom1[i]*pow(mr,j1--);                     //ubacujem x za polinom (polyval simuliram ovim)
               }
               reZ1 = (int)s1;      //zaokruzim na int aproksimiranu vrednost
               
               for(int i = 0; i < niz_MRX.size(); i++) y[i] = (double)niz_MRX.get(i);   //ista stvar jos dva puta za nereseno i pobedu gosta
               polinomX = LI.findPolynomialFactors(x, y);
               s1 = 0;
               j1 = polinomX.length-1;
               for(int i = 0; i < polinomX.length; i++)
               {
                    s1 += polinomX[i]*pow(mr,j1--);
               }
               rezX = (int)s1;
               
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);
               polinom2 = LI.findPolynomialFactors(x, y);
               s1 = 0;
               j1 = polinom1.length-1;
               for(int i = 0; i < polinom2.length; i++)
               {
                    s1 += polinom2[i]*pow(mr,j1--);
               }
               reZ2 = (int)s1;
               
               
               if(reZ1 != 0 && rezX != 0 && reZ2 != 0)
               {
                //korektivni faktori za ekipe sa vecom reputacijom i dugom tradicijom u BPL
                if(domacin.equals("Arsenal") || domacin.equals("Chelsea") || domacin.equals("Man United") 
                        || domacin.equals("Man City") || domacin.equals("Liverpool") || domacin.equals("Tottenham"))
                {
                     if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                     {
                         /*procenatX += 6;
                         procenat1 -= 2;
                         procenat2 -= 4;*/
                        /* rezX *= 1.3;
                         reZ1 /= 1.15;
                         reZ2 /= 1.15;*/
                         rezX *= 1.06;
                         reZ1 /= 1.02;
                         reZ2 /= 1.04;
                     }
                     else
                     {
                         /*procenat1 += 7;
                         procenat2 -= 4;
                         procenatX -= 3;*/
                         /*reZ1 *= 1.3;
                         rezX /= 1.15;
                         reZ2 /= 1.15;*/
                         reZ1 *= 1.07;
                         reZ2 /= 1.04;
                         rezX /= 1.03;
                     }
                }

                else if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                {
                         /*procenat2 += 4;
                         procenat1 -= 5;
                         procenatX += 1;  */
                         /*reZ2 *= 1.3;
                         reZ1 /= 1.25;
                         rezX *= 1.05;*/
                         reZ1 /= 1.11;
                         reZ2 *= 1.1;
                         rezX *= 1.01;
                }               
               }
               
               
               
               
               double rez[] = {reZ1,rezX,reZ2};
               return rez;
    }
    
    double[] Regresija(double mr, String domacin, String gost)
    {
        Regression r = new Regression();

               double polinom1[] = new double[stepen];               //polinom za pobedu domacina
               double polinomX[] = new double[stepen];               //polinom za neresen ishod
               double polinom2[] = new double[stepen];               //polinom za pobedu gosta
               double y[] = new double[niz_MR.size()];                      //y koje cemo poslati u algoritam
              
                // int stepen = 50;
                         
               for(int i = 0; i < niz_MRHW.size(); i++) y[i] = (double)niz_MRHW.get(i);         //uzimamo vrednosti y iz lista    
               polinom1 = r.regresijaPolinom(x, y, stepen);                   //nalazimo polinom
               double s1 = 0;                                               //vrednost polinoma u tacki MR koju smo sracunali ce biti ovde
               int j1 = 0;                                  //stepen polinoma-1
               for(int i = polinom1.length-1; i >= 0 ; --i)
               {
                    s1 += polinom1[j1]*pow(mr,j1++);                     //ubacujem x za polinom (polyval simuliram ovim)
               }
               reZ1 = (int)s1;      //zaokruzim na int aproksimiranu vrednost
               
               for(int i = 0; i < niz_MRX.size(); i++) y[i] = (double)niz_MRX.get(i);   //ista stvar jos dva puta za nereseno i pobedu gosta
               polinomX = r.regresijaPolinom(x, y, stepen);  
               s1 = 0;
               j1 = 0;
               for(int i = polinomX.length-1; i >= 0 ; --i)
               {
                    s1 += polinomX[j1]*pow(mr,j1++);
               }
               rezX = (int)s1;
               
               
               for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);
               polinom2 = r.regresijaPolinom(x, y, stepen);  
               s1 = 0;
               j1 = 0;
               for(int i =  polinom2.length-1; i >= 0; --i)
               {
                    s1 += polinom2[j1]*pow(mr,j1++);
               }
               reZ2 = (int)s1;
               
               if(reZ1 != 0 && rezX != 0 && reZ2 != 0)
               {
                //korektivni faktori za ekipe sa vecom reputacijom i dugom tradicijom u BPL
                if(domacin.equals("Arsenal") || domacin.equals("Chelsea") || domacin.equals("Man United") 
                        || domacin.equals("Man City") || domacin.equals("Liverpool") || domacin.equals("Tottenham"))
                {
                     if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                     {
                         /*procenatX += 6;
                         procenat1 -= 2;
                         procenat2 -= 4;*/
                        /* rezX *= 1.3;
                         reZ1 /= 1.15;
                         reZ2 /= 1.15;*/
                         rezX *= 1.06;
                         reZ1 /= 1.02;
                         reZ2 /= 1.04;
                     }
                     else
                     {
                         /*procenat1 += 7;
                         procenat2 -= 4;
                         procenatX -= 3;*/
                         /*reZ1 *= 1.3;
                         rezX /= 1.15;
                         reZ2 /= 1.15;*/
                         reZ1 *= 1.07;
                         reZ2 /= 1.04;
                         rezX /= 1.03;
                     }
                }

                else if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                {
                         /*procenat2 += 4;
                         procenat1 -= 5;
                         procenatX += 1;  */
                         /*reZ2 *= 1.3;
                         reZ1 /= 1.25;
                         rezX *= 1.05;*/
                         reZ1 /= 1.11;
                         reZ2 *= 1.1;
                         rezX *= 1.01;
                }               
               }        
               
               
               
               
               
               double rez[] = {reZ1,rezX,reZ2};
               return rez;
   
    }
     
    double[] NNReg(double mr, String domacin, String gost)
    {
        NearestNeighbourRegression kNN = new NearestNeighbourRegression(koef);
        
        double y[] = new double[niz_MR.size()];                      //y koje cemo poslati u algoritam
               
        for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRHW.get(i);

        reZ1 = (int)kNN.getResult(x, y, mr);

        for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRX.get(i);

        rezX = (int)kNN.getResult(x, y, mr);

        for(int i = 0; i < niz_MRAW.size(); i++) y[i] = (double)niz_MRAW.get(i);

        reZ2 = (int)kNN.getResult(x, y, mr);
               
                if(reZ1 != 0 && rezX != 0 && reZ2 != 0)
               {
                //korektivni faktori za ekipe sa vecom reputacijom i dugom tradicijom u BPL
                if(domacin.equals("Arsenal") || domacin.equals("Chelsea") || domacin.equals("Man United") 
                        || domacin.equals("Man City") || domacin.equals("Liverpool") || domacin.equals("Tottenham"))
                {
                     if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                     {
                         /*procenatX += 6;
                         procenat1 -= 2;
                         procenat2 -= 4;*/
                        /* rezX *= 1.3;
                         reZ1 /= 1.15;
                         reZ2 /= 1.15;*/
                         rezX *= 1.06;
                         reZ1 /= 1.02;
                         reZ2 /= 1.04;
                     }
                     else
                     {
                         /*procenat1 += 7;
                         procenat2 -= 4;
                         procenatX -= 3;*/
                         /*reZ1 *= 1.3;
                         rezX /= 1.15;
                         reZ2 /= 1.15;*/
                         reZ1 *= 1.07;
                         reZ2 /= 1.04;
                         rezX /= 1.03;
                     }
                }

                else if(gost.equals("Arsenal") || gost.equals("Chelsea") || gost.equals("Man United") 
                         || gost.equals("Man City") || gost.equals("Liverpool") || gost.equals("Tottenham"))
                {
                         /*procenat2 += 4;
                         procenat1 -= 5;
                         procenatX += 1;  */
                         /*reZ2 *= 1.3;
                         reZ1 /= 1.25;
                         rezX *= 1.05;*/
                         reZ1 /= 1.11;
                         reZ2 *= 1.1;
                         rezX *= 1.01;
                }               
               }
               
        double rez[] = {reZ1,rezX,reZ2};
        return rez;
    }

 

    public double[] getRez2() {
        return rez2;
    }


    public int getBrojUtakmica() {
        return brojUtakmica;
    }

    private double[] neuronska(String domacin, String gost, NeuralNetwork neuralNet) {
                      //neuronska

                 
                 double []nizTest = new double[8]; 
                 //nizTest[10] = 0.0; nizTest[8] = 0.0; nizTest[9] = 0;
                Scanner fileIn2 = null;
		try {
			fileIn2 = new Scanner(new File("timoviRating17.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(fileIn2.hasNext())
		{
			String line = fileIn2.nextLine();
			String pom[] = line.split(":");
                        String pom2[] = pom[1].split(",");
                        if(pom[0].equals(domacin))
                        {
                            double golmanH = Double.parseDouble(pom2[0]);
                            double odbranaH = Double.parseDouble(pom2[1]);
                            double sredinaH = Double.parseDouble(pom2[2]);
                            double napadH = Double.parseDouble(pom2[3]);
                            nizTest[0] = golmanH; nizTest[1] = odbranaH; nizTest[2] = sredinaH; nizTest[3] = napadH;
                        }
                        
                        if(pom[0].equals(gost))
                        {
                            double golmanH = Double.parseDouble(pom2[0]);
                            double odbranaH = Double.parseDouble(pom2[1]);
                            double sredinaH = Double.parseDouble(pom2[2]);
                            double napadH = Double.parseDouble(pom2[3]);
                            nizTest[4] = golmanH; nizTest[5] = odbranaH; nizTest[6] = sredinaH; nizTest[7] = napadH;
                        }
                }
                fileIn2.close();
                
                neuralNet.setInput(nizTest);
                neuralNet.calculate();
                double[] networkOutput = neuralNet.getOutput();
                return networkOutput;
    }

    
}
