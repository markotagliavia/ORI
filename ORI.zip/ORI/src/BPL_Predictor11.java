
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
/**
 *
 * @author Marko
 */
public class BPL_Predictor11 extends MyFrame {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     * 
     */
    public static void main(String[] args){

            // TODO code application logic here
            MyFrame frame = new MyFrame();
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);

        
        
    }
    
}
